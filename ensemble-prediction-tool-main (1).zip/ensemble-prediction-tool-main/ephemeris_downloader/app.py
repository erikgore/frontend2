import datetime
from ftplib import FTP_TLS
import gzip
import os
import shutil
import signal
import re
import time

_N_FILE_REGEX = re.compile(r"^\d+n$")
_BRDC_FILE_REGEX = re.compile(r"^brdc\d+.\d+n.gz")


def is_int(x) -> bool:
    try:
        int(x)
        return True
    except:
        return False


def download_latest_brdc_file(filepath):
    ftp_host = "gdc.cddis.eosdis.nasa.gov"
    print(f"Connecting to NASA CDDIS FTP at {ftp_host}")
    ftps = FTP_TLS(host=ftp_host)
    print(f"Logging in as anonymous user and securing connection")
    ftps.login(user="anonymous", passwd="")
    ftps.prot_p()

    today_year = datetime.date.today().year
    ftp_dir = f"gnss/data/daily/{today_year}"
    print(f"Changing FTP directory to {ftp_dir}")
    ftps.cwd(ftp_dir)

    max_day = max(set(int(d) for d in ftps.nlst() if is_int(d)))
    print(f"Most recent day available is {max_day}")
    ftps.cwd(str(max_day))

    n_file = [d for d in ftps.nlst() if _N_FILE_REGEX.match(str(d))][0]
    ftps.cwd(str(n_file))

    brdc_file = [d for d in ftps.nlst() if _BRDC_FILE_REGEX.match(str(d))][0]
    gz_filepath = f"{filepath}.gz"
    with open(gz_filepath, "wb") as fp:
        print(f"Downloading brdc file {brdc_file} to {gz_filepath}")
        ftps.retrbinary(f"RETR {brdc_file}", fp.write)
    ftps.quit()

    print(f"Unzipping {gz_filepath}")

    with gzip.open(gz_filepath, 'rb') as f_in:
        with open(filepath, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)


def graceful_shutdown_handler(signum, frame):
    print("Exiting...")
    exit(0)


if __name__ == "__main__":
    gnss_dir = os.getenv("GNSS_DIR", "/gnss_data")
    gnss_file = os.path.join(gnss_dir, "brdc")
    frequency_mins = int(os.getenv("FREQ_MINS", "30"))

    # Add signal handlers so the app shuts down instantly when SIGINT or SIGTERM is received.
    # Otherwise the app will not shut down gracefully.
    signal.signal(signal.SIGINT, graceful_shutdown_handler)
    signal.signal(signal.SIGTERM, graceful_shutdown_handler)
    while True:
        try:
            download_latest_brdc_file(gnss_file)
        except Exception as e:
            print(f"Error downloading GNSS file. Exception: {e}")
        print(f"Sleeping for {frequency_mins} minutes")
        time.sleep(frequency_mins * 60)
