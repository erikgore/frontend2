## Ephemeris downloader

Periodically downloads NASA GNSS BRDC data files to disk via FTP.

Configuration via environment variables:

* `GNSS_DIR` : Base directory for the BRDC file. Defaults to `/gnss_data`
* `FREQ_MINS` : Frequency (in minutes) to download new BRDC files (replacing the previous file)