from dash import get_app, Input, Output

from page_resources.file_downloads.downloadable_file import get_downloadable_files

app = get_app()


@app.callback(
    Output("downloadable-file-table", "data"),
    Input("file-downloads-interval", "n_intervals"),
)
def refresh_file_table(n_intervals):
    downloadable_files = []
    for file in get_downloadable_files():
        downloadable_files.append(file.to_dash())
    return downloadable_files
