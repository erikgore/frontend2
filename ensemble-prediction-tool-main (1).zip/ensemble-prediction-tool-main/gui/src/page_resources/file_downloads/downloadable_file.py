from dataclasses import dataclass
import datetime
from dateutil.parser import isoparse
import os
from typing import List

from dash.dash_table import DataTable
from humanize.filesize import naturalsize

from components.ensemble_parameters.constants import DOWNLOADS_FOLDER


@dataclass
class DownloadableFile:
    file_name: str
    file_size_bytes: float
    modified_time: datetime.datetime

    def get_file_type(self):
        split_name = self.file_name.split(".")
        if split_name:
            return split_name[-1]

    def get_download_markdown(self):
        return f"[Download](/file_downloads/{self.file_name})"

    def get_delete_markdown(self):
        return f"[Delete](/delete_file/{self.file_name})"

    def to_dash(self):
        return {"file_name": self.file_name,
                "file_size": naturalsize(self.file_size_bytes),
                "file_size_bytes": self.file_size_bytes,
                "modified_time": self.modified_time.isoformat(),
                "file_type": self.get_file_type() or "",
                "download_file_url": self.get_download_markdown(),
                "delete_file_url": self.get_delete_markdown()}

    @staticmethod
    def from_dash(d: dict):
        return DownloadableFile(file_name=d["file_name"],
                                file_size_bytes=d["file_size_bytes"],
                                modified_time=isoparse(d["modified_time"]))


def get_downloadable_files():
    for file_details in os.scandir(DOWNLOADS_FOLDER):
        name = file_details.name

        # Remove dead symlink (e.g. the latest.kml file if the file it's pointing to was deleted)
        file_path = os.path.join(DOWNLOADS_FOLDER, name)
        if os.path.islink(file_path) and not os.path.exists(file_path):
            os.unlink(file_path)

        try:
            stat = file_details.stat()
        except FileNotFoundError:
            continue
        file_size_bytes = stat.st_size
        mtime = datetime.datetime.fromtimestamp(stat.st_mtime)
        downloadable_file = DownloadableFile(file_name=name, file_size_bytes=file_size_bytes, modified_time=mtime)
        yield downloadable_file


class DownloadableFileTable:
    def __init__(self, files: List[DownloadableFile]):
        self.files = files

    def to_dash(self):
        return DataTable(id="downloadable-file-table",
                         data=[f.to_dash() for f in self.files],
                         columns=[{"id": "file_name",
                                   "name": "File Name"},
                                  {"id": "file_size",
                                   "name": "File Size"},
                                  {"id": "modified_time",
                                   "name": "Modified Time"},
                                  {"id": "file_type",
                                   "name": "File Type"},
                                  {"id": "download_file_url",
                                   "name": "Download File",
                                   "presentation": "markdown"},
                                  {"id": "delete_file_url",
                                   "name": "Delete File",
                                   "presentation": "markdown"}
                                  ],
                         editable=False,
                         hidden_columns=["file_size_bytes"],
                         sort_by=[{"column_id": "file_type",
                                   "direction": "asc"},
                                  {"column_id": "modified_time",
                                   "direction": "desc"}],
                         sort_action="native",
                         sort_mode="multi",
                         markdown_options={"link_target": "_self"})
