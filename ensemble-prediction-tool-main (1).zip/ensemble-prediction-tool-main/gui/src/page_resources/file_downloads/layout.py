from dash import dcc, html

from page_resources.file_downloads.downloadable_file import get_downloadable_files, DownloadableFileTable


def get_initial_layout():
    files = get_downloadable_files()
    table = DownloadableFileTable(files=files)
    return html.Div(children=[
        dcc.Interval(id="file-downloads-interval", interval=5 * 1000),  # Interval in milliseconds
        html.H1("File Downloads"),
        html.Div(children=[
            "Any file can be downloaded directly at http://[server URL]/file_downloads/[file name]",
            html.Br(),
            "For example, the latest kml is always available at http://[server URL]/file_downloads/latest.kml",
            html.Br(),
            "The latest csv is always available at http://[server URL]/file_downloads/latest.csv"
        ]),
        html.Br(),
        dcc.Link(href="/", children="Back to home page"),
        html.Br(),
        html.Br(),
        table.to_dash()
    ])
