import concurrent.futures
import copy
from typing import List

import pandas as pd
import requests
from dash import Input, Output, State, ctx, get_app, no_update

import tawhiri
from components.ensemble_parameters import common, input_tables

app = get_app()


@app.callback(
    Output("show-hide-results", "style"),
    Input("tawhiri-ensemble-df-json", "modified_timestamp"),
)
def show_hide_results(modified_timestamp):
    if modified_timestamp is None or modified_timestamp == -1:
        return {"display": "none"}
    else:
        return {"display": "block"}


@app.callback(
    output=dict(
        df_json=Output("tawhiri-ensemble-df-json", "data"),
        warnings_style=Output("results-warnings", "style"),
        warnings_children=Output("results-warnings", "children"),
        progress_bar_style=Output("ensemble-progress-div", "style"),
    ),
    state=dict(
        container_multifloat=State(
            "flight-ensemble-table-multifloat-container", "children"
        )
    ),
    inputs=dict(n_clicks=Input("tawhiri-ensemble-run-btn", "n_clicks")),
    progress=[
        Output("ensemble-progress-div", "style"),
        Output("ensemble-progress-message", "children"),
        Output("ensemble-progress-bar", "value"),
        Output("ensemble-progress-bar", "max"),
    ],
    prevent_initial_call=True,
    background=True,
)
def calculate_flight_ensemble(set_progress, container_multifloat, n_clicks):
    # Only run if the button was clicked (don't fire every time the table's data changes)
    callback_triggered = ctx.triggered_id
    if callback_triggered == "tawhiri-ensemble-run-btn":
        output_df = pd.DataFrame()
        results_warnings: List[str] = []

        flight_profile_to_dict_input = {}

        optional_inputs = ["altitude"]

        ensemble_container = input_tables.EnsembleContainer.from_dash(container_multifloat)

        float_configs = []
        for fc in ensemble_container.float_configs:
            if not fc.selected_launch_config_ids:
                # No flight profiles selected in the dropdown
                continue
            float_config_data = [
                d
                for d in fc.data
                if all(v is not None and v != "" for v in d.values())
            ]
            float_configs.append(
                {
                    "float_config_data": float_config_data,
                    "applies_to": fc.selected_launch_config_ids,
                    "float_config_id": fc.float_config_id,
                }
            )

        for row in ensemble_container.launch_config.data:
            if all(v != "" or k in optional_inputs for k, v in row.items()):
                row_float_configs = [
                    c
                    for c in float_configs
                    if row["flight_profile_id"] in c["applies_to"]
                ]
                for float_config in row_float_configs:
                    row_copy = copy.copy(row)
                    float_config_id = float_config["float_config_id"]
                    row_copy["float_configs"] = float_config["float_config_data"]
                    new_flight_profile_id = (
                            "Flight profile "
                            + str(row_copy["flight_profile_id"])
                            + " - Float config "
                            + float_config_id
                    )
                    row_copy["flight_profile_id"] = new_flight_profile_id
                    row_copy["flight_profile_id_original"] = row["flight_profile_id"]
                    row_copy["float_config_id"] = float_config_id
                    flight_profile_to_dict_input[new_flight_profile_id] = row_copy

        sims_completed = 0
        total_sims = len(flight_profile_to_dict_input)
        set_progress(
            (
                {"display": "block"},
                f"Completed {sims_completed} of {total_sims}",
                str(sims_completed),
                str(total_sims),
            )
        )

        # Asynchronously execute and collect results
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            future_to_flight_profile_id = {
                executor.submit(tawhiri.get_ensemble_df_from_dict_input, dict_input): flight_profile
                for flight_profile, dict_input in flight_profile_to_dict_input.items()
            }

            for future in concurrent.futures.as_completed(future_to_flight_profile_id):
                flight_profile_id = future_to_flight_profile_id[future]
                try:
                    flight_path: pd.DataFrame = future.result()
                    if len(output_df.index) == 0:
                        output_df = flight_path
                    else:
                        output_df = pd.concat([output_df, flight_path])
                    sims_completed += 1
                    set_progress(
                        (
                            {"display": "block"},
                            f"Completed {sims_completed} of {total_sims}",
                            str(sims_completed),
                            str(total_sims),
                        )
                    )
                except tawhiri.PredictionInputsException as e:
                    msg = f"Error predicting flight profile {flight_profile_id}: Invalid input. Error: {e}"
                    results_warnings.append(msg)
                except tawhiri.TawhiriException as e:
                    msg = f"Error predicting flight profile {flight_profile_id} (the flight is likely beyond the GFS forecast time window). Error message from API: {e}"
                    results_warnings.append(msg)
                except requests.HTTPError as e:
                    msg = f"Error predicting flight profile {flight_profile_id}. Error message from API: {e}"
                    results_warnings.append(msg)

        if len(output_df.index) > 0:
            # Have prediction results - update df_json
            output_df["Datetime"] = output_df["Datetime"].dt.strftime(
                "%Y-%m-%d %H:%M:%S %z"
            )
            output_df["Launch Time"] = output_df["Launch Time"].dt.strftime(
                "%Y-%m-%d %H:%M:%S %z"
            )

            # Sort the output DF by the original order it appeared in the data
            flight_profile_ids = [row["flight_profile_id"] for row in ensemble_container.launch_config.data]
            float_config_ids = [fc["float_config_id"] for fc in float_configs]
            output_df["Flight Profile Order"] = output_df[
                "Flight Profile (Original)"
            ].apply(flight_profile_ids.index)
            output_df["Float Config Order"] = output_df["Float Config ID"].apply(
                float_config_ids.index
            )

            return dict(
                df_json=output_df.sort_values(
                    ["Flight Profile Order", "Float Config Order", "Datetime"]
                ).to_json(orient="records"),
                warnings_style=common.render_error_message_container_style(
                    results_warnings
                ),
                warnings_children=common.render_simulation_errors(results_warnings),
                progress_bar_style={"display": "none"},
            )
        else:
            # Have no prediction results - no need to update df_json
            return dict(
                df_json=no_update,
                warnings_style=common.render_error_message_container_style(
                    results_warnings
                ),
                warnings_children=common.render_simulation_errors(results_warnings),
                progress_bar_style={"display": "none"},
            )
