import base64
import datetime
import io
import math
from functools import lru_cache
from typing import List, Optional

import cartopy.crs as ccrs
import cartopy.feature as cfeature
import dash_bootstrap_components as dbc
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import plotly.express as px
from cartopy.io.img_tiles import OSM, Stamen
from dash import Input, Output, State, get_app, dcc, no_update

import tawhiri
from components.ensemble_parameters import camera, colors
from page_resources.home.callbacks.util import render_figure_as_image

app = get_app()


@lru_cache()
def hex_to_rgb(
        hex_color: str, opacity: Optional[float] = None, as_string: Optional[bool] = False
):
    start_idx = 0
    if hex_color[0] == "#":
        start_idx = 1
    rgb = [
        int(hex_color[i: i + 2], 16) for i in (start_idx, start_idx + 2, start_idx + 4)
    ]
    if opacity is not None:
        rgb.append(opacity)
    rgb = tuple(rgb)

    if as_string:
        if opacity is not None:
            return f"rgba{rgb}"
        return f"rgb{rgb}"
    else:
        return rgb


@lru_cache()
def diff_rgb(rgb1: tuple, rgb2: tuple):
    s = 0
    for idx in range(3):
        s += math.pow(rgb1[idx] - rgb2[idx], 2)
    return math.sqrt(s)


@lru_cache()
def get_text_color(bg_color_hex: str) -> str:
    white_rgb = (0, 0, 0)
    black_rgb = (255, 255, 255)
    bg_color_rgb = hex_to_rgb(bg_color_hex)

    white_diff = diff_rgb(white_rgb, bg_color_rgb)
    black_diff = diff_rgb(black_rgb, bg_color_rgb)
    return "#000000" if white_diff > black_diff else "#FFFFFF"


def estimate_zoom_level(lons: List[float], lats: List[float], width_to_height: float = 2.0) -> float:
    """Finds optimal zoom and centering for a plotly mapbox.
    Temporary solution awaiting official implementation, see:
    https://github.com/plotly/plotly.js/issues/3434

    Mapbox docs: https://docs.mapbox.com/help/glossary/zoom-level/

    Assumes Mercator projection.

    Parameters
    --------
    lons: tuple, optional, longitude component of each location
    lats: tuple, optional, latitude component of each location
    width_to_height: float, expected ratio of final graph's with to height,
        used to select the constrained axis.

    Returns
    --------
    zoom: float, from 1 to 20
    """
    maxlon, minlon = max(lons), min(lons)
    maxlat, minlat = max(lats), min(lats)

    # longitudinal range by zoom level (20 to 1)
    # in degrees, if centered at equator
    lon_zoom_range = np.array([
        0.0007, 0.0014, 0.003, 0.006, 0.012, 0.024, 0.048, 0.096,
        0.192, 0.3712, 0.768, 1.536, 3.072, 6.144, 11.8784, 23.7568,
        47.5136, 98.304, 190.0544, 360.0
    ])

    margin = 1.4
    height = (maxlat - minlat) * margin * width_to_height
    width = (maxlon - minlon) * margin
    lon_zoom = np.interp(width, lon_zoom_range, range(20, 0, -1))
    lat_zoom = np.interp(height, lon_zoom_range, range(20, 0, -1))
    zoom = round(min(lon_zoom, lat_zoom), 2)

    return zoom


@app.callback(
    output=dict(
        map_children=Output("tawhiri-ensemble-map-loading", "children"),
        map_progress_div_style=Output("map-progress-div", "style"),
    ),
    inputs=dict(
        df_json=Input("tawhiri-ensemble-df-json", "data"),
        regen_map_n_clicks=Input("regenerate-map-btn", "n_clicks"),
    ),
    state=dict(
        gfs_info_json=State("latest-gfs-dataset-datetime", "data"),
        camera_enable=State("camera-enable", "value"),
        camera_degrees_fov_long_side=State("camera-degrees-fov-long-side", "value"),
        camera_degrees_fov_short_side=State("camera-degrees-fov-short-side", "value"),
        camera_pixels_long_side=State("camera-pixels-long-side", "value"),
        camera_pixels_short_side=State("camera-pixels-short-side", "value"),
        camera_side=State("camera-side", "value"),
        camera_frequency_ascent_descent_mins=State(
            "camera-frequency-ascent-descent-mins", "value"
        ),
        camera_frequency_float_mins=State("camera-frequency-float-mins", "value"),
        camera_opacity=State("camera-opacity", "value"),
        map_showmarkers=State("map-settings-showmarkers", "value"),
        mapbox_style=State("mapbox-style", "value"),
        color_palette_str=State("color-palette-dropdown", "value"),
        color_palette_reverse=State("color-palette-reverse", "value"),
        sim_name=State("sim-name-input", "value"),
        low_bandwidth_mode=State("low-bandwidth-mode", "value"),
    ),
    progress=[
        Output("map-progress-div", "style"),
        Output("map-progress-message-camera", "children"),
        Output("map-progress-bar-camera", "value"),
        Output("map-progress-bar-camera", "max"),
    ],
    prevent_initial_call=True,
    background=True,
)
def get_ensemble_map(
        set_progress,
        df_json,
        gfs_info_json: dict,
        camera_enable: List[str],
        camera_degrees_fov_long_side: Optional[float],
        camera_degrees_fov_short_side: Optional[float],
        camera_pixels_long_side: Optional[float],
        camera_pixels_short_side: Optional[float],
        camera_side: List[str],
        camera_frequency_ascent_descent_mins: Optional[int],
        camera_frequency_float_mins: Optional[int],
        camera_opacity: Optional[float],
        map_showmarkers: List[str],
        mapbox_style: str,
        color_palette_str: str,
        color_palette_reverse: List[str],
        regen_map_n_clicks,
        sim_name: str,
        low_bandwidth_mode: List[str]
):
    df = pd.read_json(df_json, orient="records")
    time_now = datetime.datetime.now(tz=datetime.timezone.utc).isoformat()

    title = "Predicted Flight Paths"
    if sim_name:
        title += f" ({sim_name})"
    if gfs_info_json:
        gfs_info = tawhiri.GFSInfo.from_dash_json(gfs_info_json)
        title += (
            f" - GFS dataset {gfs_info.dataset_timestamp}"
        )
    title += f" - Sim Time {time_now}"

    num_colors = df["Flight Profile"].unique().size
    palette = colors.get_color_from_name(
        color_palette_str, num_colors, color_palette_reverse
    )

    zoom_level = estimate_zoom_level(df["Longitude"], df["Latitude"])

    fig = px.line_mapbox(
        data_frame=df,
        lat="Latitude",
        lon="Longitude",
        color="Flight Profile",
        hover_name="Flight Profile",
        hover_data=["Datetime", "Altitude (m)", "Latitude", "Longitude"],
        mapbox_style=mapbox_style,
        height=1000,
        title=title,
        color_discrete_sequence=palette,
        zoom=zoom_level
    )

    if map_showmarkers or camera_enable:
        fig.for_each_trace(
            lambda t: t.update(
                legendgroup="Flight Paths", legendgrouptitle={"text": "Flight Paths"}
            )
        )
        fig.update_layout(legend_title="", legend_groupclick="togglegroup")

        start_ascent_descent = pd.DataFrame()
        stop_ascent_descent = pd.DataFrame()

        for flight_profile_name, flight_profile_df in df.groupby("Flight Profile"):
            flight_profile_df["Vertical Speed (t-1)"] = flight_profile_df[
                "Vertical Speed (m/s)"
            ].shift(1)
            flight_profile_df["Vertical Speed (t+1)"] = flight_profile_df[
                "Vertical Speed (m/s)"
            ].shift(-1)
            start_ascent_descent_fp = flight_profile_df.loc[
                (flight_profile_df["Vertical Speed (t-1)"] == 0)
                & (flight_profile_df["Vertical Speed (m/s)"] == 0)
                & (flight_profile_df["Vertical Speed (t+1)"] != 0)
                ]
            stop_ascent_descent_fp = flight_profile_df.loc[
                (flight_profile_df["Vertical Speed (t-1)"] != 0)
                & (flight_profile_df["Vertical Speed (m/s)"] == 0)
                & (flight_profile_df["Vertical Speed (t+1)"] == 0)
                ]

            if len(start_ascent_descent.index) == 0:
                start_ascent_descent = start_ascent_descent_fp
            else:
                start_ascent_descent = pd.concat(
                    [start_ascent_descent, start_ascent_descent_fp]
                )

            if len(stop_ascent_descent.index) == 0:
                stop_ascent_descent = stop_ascent_descent_fp
            else:
                stop_ascent_descent = pd.concat(
                    [stop_ascent_descent, stop_ascent_descent_fp]
                )

    if map_showmarkers:
        launch_locs = df.groupby("Flight Profile").first().reset_index()
        fig.add_scattermapbox(
            name="Launch",
            mode="markers",
            lat=launch_locs["Latitude"],
            lon=launch_locs["Longitude"],
            marker={"color": "green", "size": 12},
            legendgroup="Markers",
            legendgrouptitle={"text": "Markers"},
            hoverinfo="text",
            hovertext=launch_locs.apply(
                lambda
                    r: "Flight Profile: {}<br>Launch<br><br>Latitude: {}<br>Longitude: {}<br>Datetime: {}<br>Altitude (m): {}".format(
                    r["Flight Profile"],
                    r["Latitude"],
                    r["Longitude"],
                    r["Datetime"],
                    r["Altitude (m)"],
                ),
                axis=1,
            ),
        )

        land_locs = df.groupby("Flight Profile").last().reset_index()
        fig.add_scattermapbox(
            name="Landing",
            mode="markers",
            lat=land_locs["Latitude"],
            lon=land_locs["Longitude"],
            marker={"color": "red", "size": 12},
            legendgroup="Markers",
            legendgrouptitle={"text": "Markers"},
            hoverinfo="text",
            hovertext=land_locs.apply(
                lambda
                    r: "Flight Profile: {}<br>Landing<br><br>Latitude: {}<br>Longitude: {}<br>Datetime: {}<br>Altitude (m): {}".format(
                    r["Flight Profile"],
                    r["Latitude"],
                    r["Longitude"],
                    r["Datetime"],
                    r["Altitude (m)"],
                ),
                axis=1,
            ),
        )

        fig.add_scattermapbox(
            name="Start Ascent/Descent",
            mode="markers",
            lat=start_ascent_descent["Latitude"],
            lon=start_ascent_descent["Longitude"],
            marker={"color": "yellow", "size": 12},
            legendgroup="Markers",
            legendgrouptitle={"text": "Markers"},
            hoverinfo="text",
            hovertext=start_ascent_descent.apply(
                lambda
                    r: "Flight Profile: {}<br>Start Ascent/Descent<br><br>Latitude: {}<br>Longitude: {}<br>Datetime: {}<br>Altitude (m): {}".format(
                    r["Flight Profile"],
                    r["Latitude"],
                    r["Longitude"],
                    r["Datetime"],
                    r["Altitude (m)"],
                ),
                axis=1,
            ),
        )
        fig.add_scattermapbox(
            name="Stop Ascent/Descent",
            mode="markers",
            lat=stop_ascent_descent["Latitude"],
            lon=stop_ascent_descent["Longitude"],
            marker={"color": "blue", "size": 12},
            legendgroup="Markers",
            legendgrouptitle={"text": "Markers"},
            hoverinfo="text",
            hovertext=stop_ascent_descent.apply(
                lambda
                    r: "Flight Profile: {}<br>Stop Ascent/Descent<br><br>Latitude: {}<br>Longitude: {}<br>Datetime: {}<br>Altitude (m): {}".format(
                    r["Flight Profile"],
                    r["Latitude"],
                    r["Longitude"],
                    r["Datetime"],
                    r["Altitude (m)"],
                ),
                axis=1,
            ),
        )

        sunrise_sunsets = pd.DataFrame()
        for flight_profile_name, flight_profile_df in df.groupby("Flight Profile"):
            sunrise_sunset = flight_profile_df.loc[
                (
                        (flight_profile_df["Solar Angle (Altitude)"].shift() < 0)
                        & (flight_profile_df["Solar Angle (Altitude)"].shift(-1) >= 0)
                )
                | (
                        (flight_profile_df["Solar Angle (Altitude)"].shift() > 0)
                        & (flight_profile_df["Solar Angle (Altitude)"].shift(-1) <= 0)
                )
                ].copy()
            sunrise_sunset["Datetime Change (s)"] = (
                sunrise_sunset["Datetime"].diff().dt.total_seconds()
            )
            # Due to the logic above, sometimes 2 data points in a row get picked up
            # This removes the second (extraneous) data point
            sunrise_sunset["Dupe"] = sunrise_sunset["Datetime Change (s)"] < 60 * 60
            sunrise_sunset = sunrise_sunset.loc[~sunrise_sunset["Dupe"]]

            if len(sunrise_sunsets.index) == 0:
                sunrise_sunsets = sunrise_sunset
            else:
                sunrise_sunsets = pd.concat([sunrise_sunsets, sunrise_sunset])

        fig.add_scattermapbox(
            name="Sunrise/Sunset",
            mode="markers",
            lat=sunrise_sunsets["Latitude"],
            lon=sunrise_sunsets["Longitude"],
            marker={"color": "orange", "size": 12},
            legendgroup="Markers",
            legendgrouptitle={"text": "Markers"},
            hoverinfo="text",
            hovertext=sunrise_sunsets.apply(
                lambda
                    r: "Flight Profile: {}<br>Sunrise/Sunset<br><br>Latitude: {}<br>Longitude: {}<br>Datetime: {}<br>Altitude (m): {}".format(
                    r["Flight Profile"],
                    r["Latitude"],
                    r["Longitude"],
                    r["Datetime"],
                    r["Altitude (m)"],
                ),
                axis=1,
            ),
        )

    if (
            camera_enable
            and camera_frequency_ascent_descent_mins is not None
            and camera_frequency_float_mins is not None
            and camera_side
    ):

        camera_sims_completed = 0
        total_sims = df["Flight Profile"].unique().size
        num_camera_sides = len(camera_side)
        total_camera_sims = total_sims * num_camera_sides
        set_progress(
            (
                {"display": "block"},
                f"Completed {camera_sims_completed} of {total_camera_sims} camera image calculations ({num_camera_sides} side(s) * {total_sims} sims)",
                str(camera_sims_completed),
                str(total_camera_sims),
            )
        )

        for side in camera_side:
            if side == "Short Side":
                cam = camera.Camera(
                    camera_degrees_fov_short_side,
                    camera_pixels_short_side,
                )
            elif side == "Long Side":
                cam = camera.Camera(
                    camera_degrees_fov_long_side,
                    camera_pixels_long_side,
                )
            color_idx = 0
            max_color_idx = len(palette) - 1

            for flight_profile_name, flight_profile_df in df.groupby("Flight Profile"):
                lats = []
                lons = []
                hovertexts = []

                initial_ascent_cutoff = stop_ascent_descent.loc[
                    stop_ascent_descent["Flight Profile"] == flight_profile_name
                    ]["Datetime"].min()
                final_descent_cutoff = start_ascent_descent.loc[
                    start_ascent_descent["Flight Profile"] == flight_profile_name
                    ]["Datetime"].max()

                ascent_descent = flight_profile_df.loc[
                    (flight_profile_df["Datetime"] < initial_ascent_cutoff)
                    | (flight_profile_df["Datetime"] > final_descent_cutoff)
                    ]
                float_df = flight_profile_df.loc[
                    (flight_profile_df["Datetime"] >= initial_ascent_cutoff)
                    & (flight_profile_df["Datetime"] <= final_descent_cutoff)
                    ]

                for resample_rate, df_to_resample in [
                    (camera_frequency_ascent_descent_mins, ascent_descent),
                    (camera_frequency_float_mins, float_df),
                ]:
                    resample_str = f"{resample_rate}Min"
                    resampled = (
                        df_to_resample.resample(resample_str, on="Datetime")
                        .first()
                        .reset_index()
                        .dropna(subset=["Latitude", "Longitude"])
                    )
                    resampled["Altitude (m, AGL)"] = resampled.apply(lambda x: tawhiri.get_altitude_m_agl(
                        x["Altitude (m)"], x["Latitude"], x["Longitude"]
                    ), axis=1)
                    resampled["Image Radius (m)"] = resampled["Altitude (m, AGL)"] * cam.fov_radians_tan
                    resampled["Avg Pixel Size (m)"] = resampled["Image Radius (m)"] / cam.pixels
                    resampled["Nadir Pixel Size (m)"] = resampled["Altitude (m, AGL)"] * cam.pixel_angle_radians_tan

                    for _, row in resampled.iterrows():
                        hovertext = f"Flight Profile {flight_profile_name} - Camera Coverage<br>{side}<br><br>Latitude: {round(row['Latitude'], 5)}<br>Longitude: {round(row['Longitude'], 5)}<br>Datetime: {row['Datetime']}<br>Altitude(m, ASL): {round(int(row['Altitude (m)']))}<br>Altitude (m, AGL): {int(row['Altitude (m, AGL)'])}<br>Pixel Size (m, avg): {int(row['Avg Pixel Size (m)'])}<br>Pixel Size (m, nadir): {int(row['Nadir Pixel Size (m)'])}<br>Image Radius (m): {int(row['Image Radius (m)'])}"
                        corners = cam.get_image_corners(row["Altitude (m, AGL)"], row["Latitude"], row["Longitude"])
                        for corner in corners:
                            lats.append(corner.latitude)
                            lons.append(corner.longitude)
                            hovertexts.append(hovertext)
                        lats.append(None)
                        lons.append(None)
                        hovertexts.append(None)

                if color_idx == max_color_idx:
                    color_idx = 0
                bg_color_hex = palette[color_idx]
                bg_color = hex_to_rgb(
                    bg_color_hex, opacity=camera_opacity, as_string=True
                )
                text_color = get_text_color(bg_color_hex)

                color_idx += 1

                fig.add_scattermapbox(
                    lat=lats,
                    lon=lons,
                    mode="lines",
                    fill="toself",
                    name=f"{flight_profile_name} (Camera - {side})",
                    hovertext=hovertexts,
                    hoverinfo="text",
                    fillcolor=bg_color,
                    line={"width": 0},
                    hoverlabel={
                        "bgcolor": bg_color_hex,
                        "bordercolor": bg_color_hex,
                        "font": {"color": text_color},
                    },
                    legendgroup=f"Camera Coverage - {side}",
                    legendgrouptitle={"text": f"Camera Coverage - {side}"},
                )

                camera_sims_completed += 1
                set_progress(
                    (
                        {"display": "block"},
                        f"Completed {camera_sims_completed} of {total_camera_sims} camera image calculations ({num_camera_sides} side(s) * {total_sims} sims)",
                        str(camera_sims_completed),
                        str(total_camera_sims),
                    )
                )

    if low_bandwidth_mode:
        output = render_figure_as_image(fig, width=1555, height=1000)
    else:
        output = dcc.Graph(figure=fig)
    return dict(map_children=output, map_progress_div_style={"display": "none"})


def get_gfs_datetimes(gfs_info: tawhiri.GFSInfo, min_dt: datetime.datetime, max_dt: datetime.datetime):
    max_dt_3h = gfs_info.dataset_timestamp + datetime.timedelta(hours=240)
    max_dt_12h = gfs_info.dataset_timestamp + datetime.timedelta(hours=384)

    date_range_3h = pd.date_range(gfs_info.dataset_timestamp, max_dt_3h, freq="3H")
    date_range_12h = pd.date_range(max_dt_3h, max_dt_12h)
    full_date_range = date_range_3h.append(date_range_12h).to_pydatetime().tolist()

    max_gfs_hour = gfs_info.dataset_timestamp + datetime.timedelta(hours=gfs_info.forecast_hours)
    return [d for d in full_date_range if (min_dt <= d <= max_dt) and (d <= max_gfs_hour)]


def get_gfs_lat_lon(min_lat: float, max_lat: float, min_lon: float, max_lon: float):
    gfs_min_lat = math.ceil(min_lat * 4) / 4
    gfs_min_lon = math.ceil(min_lon * 4) / 4
    gfs_max_lat = math.floor(max_lat * 4) / 4
    gfs_max_lon = math.floor(max_lon * 4) / 4

    lats = np.arange(gfs_min_lat, gfs_max_lat, 0.25).tolist() + [gfs_max_lat]
    lons = np.arange(gfs_min_lon, gfs_max_lon, 0.25).tolist() + [gfs_max_lon]
    return lats, lons


@app.callback(
    output=dict(
        wind_quiver_tabs_value=Output("wind-quiver-tabs", "value"),
        wind_quiver_tabs_children=Output("wind-quiver-tabs", "children"),
        wind_quiver_div_style=Output("wind-quiver-map-div", "style"),
        wind_progress_div_style=Output("wind-map-progress-div", "style"),
    ),
    inputs=dict(
        df_json=Input("tawhiri-ensemble-df-json", "data"),
        show_wind_map=Input("wind-map-enable", "value"),
        wind_map_style=Input("wind-map-style-dropdown", "value")
    ),
    progress=[
        Output("wind-map-progress-div", "style"),
        Output("wind-map-progress-message", "children"),
        Output("wind-map-progress-bar", "value"),
        Output("wind-map-progress-bar", "max")
    ],
    prevent_initial_call=True,
    background=True,
)
def get_wind_quiver_maps(set_progress, df_json, show_wind_map, wind_map_style):
    if not show_wind_map:
        return dict(wind_quiver_tabs_value=no_update,
                    wind_quiver_tabs_children=no_update,
                    wind_quiver_div_style={"display": "none"},
                    wind_progress_div_style={"display": "none"})
    df = pd.read_json(df_json, orient="records")
    min_lat = df["Latitude"].min() - 1
    max_lat = df["Latitude"].max() + 1
    min_lon = df["Longitude"].min() - 1
    max_lon = df["Longitude"].max() + 1
    gfs_lats, gfs_lons = get_gfs_lat_lon(min_lat, max_lat, min_lon, max_lon)

    try:
        gfs_info = tawhiri.get_gfs_info()
    except Exception as e:
        app.logger.error(f"Error fetching GFS info. Exception: {e}")
        return dict(wind_quiver_tabs_value=no_update,
                    wind_quiver_tabs_children=no_update,
                    wind_quiver_div_style={"display": "none"},
                    wind_progress_div_style={"display": "none"})
    min_dt = df["Datetime"].min()
    max_dt = df["Datetime"].max()
    gfs_datetimes = get_gfs_datetimes(gfs_info, min_dt, max_dt)

    min_altitude = 0
    max_altitude = 25000
    step_altitude = 5000
    altitudes = np.arange(min_altitude, max_altitude, step_altitude).tolist() + [max_altitude]

    request_dicts = []
    for alt in altitudes:
        for lat in gfs_lats:
            for lon in gfs_lons:
                for dt in gfs_datetimes:
                    dt_str = dt.isoformat(timespec="seconds")
                    request_dicts.append({
                        "datetime": dt_str,
                        "latitude": float(lat),
                        "longitude": float(lon),
                        "altitude": int(alt)
                    })

    set_progress(
        (
            {"display": "block"},
            f"Fetching wind speed data from Tawhiri API",
            None,
            None,
        )
    )

    try:
        wind_speeds_df = tawhiri.get_wind_speeds(request_dicts)
    except Exception as e:
        app.logger.error(f"Error fetching wind speeds. Exception: {e}")
        return dict(wind_quiver_tabs_value=no_update,
                    wind_quiver_tabs_children=no_update,
                    wind_quiver_div_style={"display": "none"},
                    wind_progress_div_style={"display": "none"})
    tabs = []

    use_map_styles = False
    tiler = None
    crs = ccrs.PlateCarree()
    if wind_map_style == "open-street-map":
        tiler = OSM()
        crs = tiler.crs
        use_map_styles = True
    elif wind_map_style == "stamen-terrain":
        tiler = Stamen("terrain")
        crs = tiler.crs
        use_map_styles = True

    num_figures = int(len(gfs_datetimes) * len(altitudes))
    figure_idx = 1

    for dt in gfs_datetimes:
        dt_str = dt.isoformat(timespec="seconds")
        dt_str_pretty = "{} UTC".format(dt.strftime("%Y-%m-%d %H:%M:%S"))
        carousel_images = []

        for alt in altitudes:
            set_progress(
                (
                    {"display": "block"},
                    f"Generating wind speed image {figure_idx} of {num_figures}",
                    str(figure_idx),
                    str(num_figures),
                )
            )

            plt.Figure(figsize=(12, 12))
            alt_df = wind_speeds_df.loc[(wind_speeds_df["altitude"] == alt) & (wind_speeds_df["datetime"] == dt_str)]
            x = alt_df["longitude"]
            y = alt_df["latitude"]
            u = alt_df["u"]
            v = alt_df["v"]

            ax = plt.axes(projection=crs)
            ax.set_extent([min(gfs_lons), max(gfs_lons), min(gfs_lats), max(gfs_lats)], ccrs.PlateCarree())
            if use_map_styles:
                ax.add_image(tiler, 7)
            else:
                ax.add_feature(cfeature.STATES)
                ax.add_feature(cfeature.COASTLINE)
                ax.add_feature(cfeature.LAND)
                ax.add_feature(cfeature.OCEAN)
                ax.add_feature(cfeature.BORDERS, linestyle=':')
                ax.add_feature(cfeature.LAKES, alpha=0.5)
                ax.add_feature(cfeature.RIVERS)
                ax.add_feature(cfeature.NaturalEarthFeature(category="cultural",
                                                            name="populated_places",
                                                            scale="10m"))
            ax.set_title(f'GFS wind speeds - {dt_str_pretty} at {alt}m')
            ax.quiver(x, y, u, v, transform=ccrs.PlateCarree())

            with io.BytesIO() as buf:
                plt.savefig(buf, format="png", dpi=300, bbox_inches='tight', pad_inches=0.1)
                plt.close()
                data = base64.b64encode(buf.getvalue()).decode("utf8")  # encode to html element
                data_str = "data:image/png;base64,{}".format(data)
                carousel_image = {
                    "src": data_str,
                    "img_style": {"width": "100%", "height": "100%"}
                }
                carousel_images.append(carousel_image)
                figure_idx += 1
        tab_carousel = dbc.Carousel(interval=None,
                                    slide=False,
                                    variant="dark",
                                    items=carousel_images)
        tab = dcc.Tab(label=dt_str_pretty, value=dt_str, children=tab_carousel)
        tabs.append(tab)

    return dict(wind_quiver_tabs_value=min(gfs_datetimes).isoformat(timespec="seconds"),
                wind_quiver_tabs_children=tabs,
                wind_quiver_div_style={"display": "block"},
                wind_progress_div_style={"display": "none"})
