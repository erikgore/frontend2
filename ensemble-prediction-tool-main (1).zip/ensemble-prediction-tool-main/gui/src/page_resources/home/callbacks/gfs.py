import datetime
from typing import Optional

from dash import Input, Output, get_app, no_update

import tawhiri
from components.ensemble_parameters import common, input_tables

app = get_app()


@app.callback(
    Output("latest-gfs-dataset-message", "children"),
    Output("latest-gfs-dataset-datetime", "data"),
    Input("latest-gfs-dataset-interval", "n_intervals"),
)
def refresh_gfs_dataset_timestamp(n):
    try:
        latest_timestamp: Optional[tawhiri.GFSInfo] = tawhiri.get_gfs_info()
        if latest_timestamp:
            gfs_cutoff = latest_timestamp.dataset_timestamp + datetime.timedelta(hours=latest_timestamp.forecast_hours)
            return f"Latest GFS dataset: {latest_timestamp.dataset_timestamp} (forecasting {latest_timestamp.forecast_hours} hrs to {gfs_cutoff})", latest_timestamp.to_dash_json()
    except tawhiri.GFSEndpointNotFoundException:
        return "GFS datasetcheck endpoint not found", ""
    except tawhiri.GFSDatasetNotFoundException:
        return "GFS dataset not found", ""


@app.callback(Output("input-validation-warnings", "style"),
              Output("input-validation-warnings", "children"),
              Input("show-hide-table-multifloat", "children"),
              Input("latest-gfs-dataset-datetime", "data"),
              prevent_initial_call=True)
def check_forecast_cutoff(multifloat_children, gfs_info_json: dict):
    gfs_info = tawhiri.GFSInfo.from_dash_json(gfs_info_json)
    gfs_cutoff = gfs_info.dataset_timestamp + datetime.timedelta(hours=gfs_info.forecast_hours)
    error_messages = []

    ensemble_container_raw = multifloat_children[0]["props"]["children"]
    try:
        ensemble_container = input_tables.EnsembleContainer.from_dash(ensemble_container_raw)
    except:
        return no_update, no_update

    estimated_landing_datetimes = ensemble_container.get_estimated_landing_datetimes()
    landing_past_cutoff = [dt for dt in estimated_landing_datetimes if dt.landing_datetime >= gfs_cutoff]
    if landing_past_cutoff:
        for estimated_landing_dt in landing_past_cutoff:
            message = f"Flight profile {estimated_landing_dt.flight_profile_id} - Float config {estimated_landing_dt.float_config_id} may land beyond the GFS cutoff. Estimated landing time: {estimated_landing_dt.landing_datetime}. GFS cutoff: {gfs_cutoff}"
            error_messages.append(message)

    return common.render_error_message_container_style(error_messages), common.render_error_list(
        "Warning: Some flights may extend beyond the GFS cutoff", error_messages)
