from base64 import b64encode
from io import BytesIO

from dash import html
from plotly.graph_objects import Figure


def render_figure_as_image(chart: Figure, img_format="webp", width=None, height=None) -> html.Img:
    with BytesIO() as buffer:
        chart.write_image(buffer, format=img_format, width=width, height=height)
        data = b64encode(buffer.getvalue()).decode("utf8")  # encode to html element
        data_str = "data:image/{};base64,{}".format(img_format, data)
        return html.Img(src=data_str, style={"max-width": "100%"})
