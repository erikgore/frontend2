import base64
import datetime
import io
import re
from typing import List, Optional

import numpy as np
import pandas as pd
import plotly.express as px
from dash import Input, Output, State, ALL, MATCH, ctx, no_update, get_app, dcc
from dateutil.parser import isoparse

app = get_app()

from components.ensemble_parameters import common, constants, microloon, input_tables
from page_resources.home.callbacks.util import render_figure_as_image


@app.callback(
    output=dict(latitude=Output("launch-latitude-input", "value"),
                longitude=Output("launch-longitude-input", "value"),
                lat_lon_step=Output("launch-latlon-input-step", "value"),
                lat_lon_step_num=Output("launch-latlon-input-step-num", "value"),
                altitude_min=Output("launch-altitude-input-min", "value"),
                altitude_max=Output("launch-altitude-input-max", "value"),
                altitude_step=Output("launch-altitude-input-step", "value"),
                datetime_min_date=Output("launch-datetime-min-date", "date"),
                datetime_min_hour=Output("launch-datetime-min-hour", "value"),
                datetime_min_minute=Output("launch-datetime-min-minute", "value"),
                datetime_max_date=Output("launch-datetime-max-date", "date"),
                datetime_max_hour=Output("launch-datetime-max-hour", "value"),
                datetime_max_minute=Output("launch-datetime-max-minute", "value"),
                datetime_step=Output("launch-datetime-step", "value"),
                ascent_rate_type=Output("radio-ascent-rate-type", "value"),
                fixed_ascent_rate_min=Output("ascent-rate-input-min", "value"),
                fixed_ascent_rate_max=Output("ascent-rate-input-max", "value"),
                fixed_ascent_rate_step=Output("ascent-rate-input-step", "value"),
                smoothed_ascent_rate_initial=Output("ascent-rate-smoothed-initial", "value"),
                smoothed_ascent_rate_slowing_rate=Output("ascent-rate-slowing-rate", "value"),
                smoothed_ascent_rate_slowing_rate_bin=Output("ascent-rate-slowing-rate-bin", "value"),
                float_altitude_min=Output("float-altitude-input-min", "value"),
                float_altitude_max=Output("float-altitude-input-max", "value"),
                float_altitude_step=Output("float-altitude-input-step", "value"),
                float_duration_min=Output("float-duration-input-min", "value"),
                float_duration_max=Output("float-duration-input-max", "value"),
                float_duration_step=Output("float-duration-input-step", "value"),
                camera_fov_degrees_long_side=Output("camera-degrees-fov-long-side", "value"),
                camera_fov_degrees_short_side=Output("camera-degrees-fov-short-side", "value"),
                camera_pixels_long_side=Output("camera-pixels-long-side", "value"),
                camera_pixels_short_side=Output("camera-pixels-short-side", "value"),
                camera_side=Output("camera-side", "value"),
                camera_freq_ascent_descent=Output("camera-frequency-ascent-descent-mins", "value"),
                camera_freq_float=Output("camera-frequency-float-mins", "value"),
                camera_opacity=Output("camera-opacity", "value"),
                camera_enable=Output("camera-enable", "value"),
                map_showmarkers=Output("map-settings-showmarkers", "value"),
                mapbox_style=Output("mapbox-style", "value"),
                mapbox_color_palette=Output("color-palette-dropdown", "value"),
                mapbox_color_palette_reverse=Output("color-palette-reverse", "value"),
                descent_rates=Output("descent-rate-input", "value"),
                sim_name=Output("sim-name-input", "value"),
                microloon_input_checkbox=Output("microloon-input-checkbox", "value"),
                wind_map_enable=Output("wind-map-enable", "value"),
                wind_map_style=Output("wind-map-style-dropdown", "value"),
                low_bandwidth_mode=Output("low-bandwidth-mode", "value")),
    inputs=[Input("microloon-position-store", "data"), Input("reset-parameters-btn", "n_clicks")],
    prevent_initial_call=True
)
def update_inputs(microloon_store_data, reset_params_n_clicks):
    if ctx.triggered_id == "microloon-position-store":
        # Update parameters from latest Microloon data
        data = microloon.GPSPosition.from_json(microloon_store_data)
        data_datetime = isoparse(data.time_)
        return dict(latitude=round(data.latitude, 5),
                    longitude=round(data.longitude, 5),
                    altitude_min=int(data.altitude_m),
                    altitude_max=int(data.altitude_m),
                    datetime_min_date=data_datetime.date(),
                    datetime_min_hour=data_datetime.hour,
                    datetime_min_minute=data_datetime.minute,
                    datetime_max_date=data_datetime.date(),
                    datetime_max_hour=data_datetime.hour,
                    datetime_max_minute=data_datetime.minute,
                    lat_lon_step=no_update,
                    lat_lon_step_num=no_update,
                    altitude_step=no_update,
                    datetime_step=no_update,
                    ascent_rate_type=no_update,
                    fixed_ascent_rate_min=no_update,
                    fixed_ascent_rate_max=no_update,
                    fixed_ascent_rate_step=no_update,
                    smoothed_ascent_rate_initial=no_update,
                    smoothed_ascent_rate_slowing_rate=no_update,
                    smoothed_ascent_rate_slowing_rate_bin=no_update,
                    float_altitude_min=no_update,
                    float_altitude_max=no_update,
                    float_altitude_step=no_update,
                    float_duration_min=no_update,
                    float_duration_max=no_update,
                    float_duration_step=no_update,
                    camera_fov_degrees_long_side=no_update,
                    camera_fov_degrees_short_side=no_update,
                    camera_pixels_long_side=no_update,
                    camera_pixels_short_side=no_update,
                    camera_side=no_update,
                    camera_freq_ascent_descent=no_update,
                    camera_freq_float=no_update,
                    camera_opacity=no_update,
                    camera_enable=no_update,
                    map_showmarkers=no_update,
                    mapbox_style=no_update,
                    mapbox_color_palette=no_update,
                    mapbox_color_palette_reverse=no_update,
                    descent_rates=no_update,
                    sim_name=no_update,
                    microloon_input_checkbox=no_update,
                    wind_map_enable=no_update,
                    wind_map_style=no_update,
                    low_bandwidth_mode=no_update,
                    )

    elif ctx.triggered_id == "reset-parameters-btn":
        default_inputs = common.EnsembleFormInputs()
        descent_rates_str = ",".join(str(s) for s in default_inputs.descent_rate_inputs.descent_rates)
        color_palette_reverse = ["Reverse"] if default_inputs.map_settings_inputs.reverse_color_palette else []
        map_showmarkers = ["Show"] if default_inputs.map_settings_inputs.show_key_event_markers else []
        camera_enable = ["Show"] if default_inputs.map_settings_inputs.show_camera_image_coverage else []
        wind_map_enable = ["Show"] if default_inputs.wind_map_settings_inputs.show_wind_map else []
        # Reset parameters to defaults (clearing persistent state)
        return dict(latitude=default_inputs.lat_lon_inputs.center_latitude,
                    longitude=default_inputs.lat_lon_inputs.center_longitude,
                    altitude_min=default_inputs.launch_altitude_inputs.launch_altitude_min,
                    altitude_max=default_inputs.launch_altitude_inputs.launch_altitude_max,
                    datetime_min_date=default_inputs.launch_datetime_inputs.min_launch_date,
                    datetime_min_hour=default_inputs.launch_datetime_inputs.min_launch_hour,
                    datetime_min_minute=default_inputs.launch_datetime_inputs.min_launch_minute,
                    datetime_max_date=default_inputs.launch_datetime_inputs.max_launch_date,
                    datetime_max_hour=default_inputs.launch_datetime_inputs.max_launch_hour,
                    datetime_max_minute=default_inputs.launch_datetime_inputs.max_launch_minute,
                    lat_lon_step=default_inputs.lat_lon_inputs.step_size,
                    lat_lon_step_num=default_inputs.lat_lon_inputs.num_steps_from_center,
                    altitude_step=default_inputs.launch_altitude_inputs.launch_altitude_step,
                    datetime_step=default_inputs.launch_datetime_inputs.launch_datetime_step,
                    ascent_rate_type=default_inputs.ascent_rate_inputs.ascent_rate_type.value,
                    fixed_ascent_rate_min=default_inputs.ascent_rate_inputs.fixed_ascent_rate_inputs.ascent_rate_min,
                    fixed_ascent_rate_max=default_inputs.ascent_rate_inputs.fixed_ascent_rate_inputs.ascent_rate_max,
                    fixed_ascent_rate_step=default_inputs.ascent_rate_inputs.fixed_ascent_rate_inputs.ascent_rate_step,
                    smoothed_ascent_rate_initial=default_inputs.ascent_rate_inputs.smoothed_ascent_rate_inputs.initial_ascent_rate,
                    smoothed_ascent_rate_slowing_rate=default_inputs.ascent_rate_inputs.smoothed_ascent_rate_inputs.slow_down_speed_step,
                    smoothed_ascent_rate_slowing_rate_bin=default_inputs.ascent_rate_inputs.smoothed_ascent_rate_inputs.slow_down_altitude_step,
                    float_altitude_min=default_inputs.initial_float_altitude_inputs.float_altitude_min,
                    float_altitude_max=default_inputs.initial_float_altitude_inputs.float_altitude_max,
                    float_altitude_step=default_inputs.initial_float_altitude_inputs.float_altitude_step,
                    float_duration_min=default_inputs.initial_float_duration_inputs.float_duration_min,
                    float_duration_max=default_inputs.initial_float_duration_inputs.float_duration_max,
                    float_duration_step=default_inputs.initial_float_duration_inputs.float_duration_step,
                    camera_fov_degrees_long_side=default_inputs.camera_coverage_inputs.degrees_fov_long_side,
                    camera_fov_degrees_short_side=default_inputs.camera_coverage_inputs.degrees_fov_short_side,
                    camera_pixels_long_side=default_inputs.camera_coverage_inputs.pixels_long_side,
                    camera_pixels_short_side=default_inputs.camera_coverage_inputs.pixels_short_side,
                    camera_side=default_inputs.camera_coverage_inputs.sides_selected,
                    camera_freq_ascent_descent=default_inputs.camera_coverage_inputs.plot_frequency_initial_ascent_descent,
                    camera_freq_float=default_inputs.camera_coverage_inputs.plot_frequency_float,
                    camera_opacity=default_inputs.camera_coverage_inputs.plot_opacity,
                    camera_enable=camera_enable,
                    map_showmarkers=map_showmarkers,
                    mapbox_style=default_inputs.map_settings_inputs.mapbox_style,
                    mapbox_color_palette=default_inputs.map_settings_inputs.color_palette,
                    mapbox_color_palette_reverse=color_palette_reverse,
                    descent_rates=descent_rates_str,
                    sim_name=None,
                    microloon_input_checkbox=[],
                    wind_map_enable=wind_map_enable,
                    wind_map_style=default_inputs.wind_map_settings_inputs.wind_map_style,
                    low_bandwidth_mode=[],
                    )


def get_latlon_map(
        latitudes: List[float],
        longitudes: List[float],
):
    lats = []
    lons = []
    for lat in latitudes:
        for lon in longitudes:
            lats.append(lat)
            lons.append(lon)

    fig = px.scatter_mapbox(
        lat=lats,
        lon=lons,
        mapbox_style="open-street-map",
        width=200,
        height=200,
    )
    fig.update_layout(margin={"r": 0, "t": 0, "l": 10, "b": 0})

    return fig


@app.callback(
    Output("input-validation-errors", "style"),
    Output("input-validation-errors", "children"),
    Output("show-hide-table-multifloat", "children"),
    Output("launch-datetime-min-local", "children"),
    Output("launch-datetime-max-local", "children"),
    Output("launch-latlon-map", "children"),
    Output("launch-latlon-map", "style"),
    Input("launch-latitude-input", "n_blur_timestamp"),
    State("launch-latitude-input", "value"),
    Input("launch-longitude-input", "n_blur_timestamp"),
    State("launch-longitude-input", "value"),
    Input("launch-latlon-input-step", "n_blur_timestamp"),
    State("launch-latlon-input-step", "value"),
    Input("launch-latlon-input-step-num", "n_blur_timestamp"),
    State("launch-latlon-input-step-num", "value"),
    Input("launch-altitude-input-min", "n_blur_timestamp"),
    State("launch-altitude-input-min", "value"),
    Input("launch-altitude-input-max", "n_blur_timestamp"),
    State("launch-altitude-input-max", "value"),
    Input("launch-altitude-input-step", "n_blur_timestamp"),
    State("launch-altitude-input-step", "value"),
    Input("launch-datetime-min-date", "date"),
    Input("launch-datetime-min-hour", "n_blur_timestamp"),
    State("launch-datetime-min-hour", "value"),
    Input("launch-datetime-min-minute", "n_blur_timestamp"),
    State("launch-datetime-min-minute", "value"),
    Input("launch-datetime-max-date", "date"),
    Input("launch-datetime-max-hour", "n_blur_timestamp"),
    State("launch-datetime-max-hour", "value"),
    Input("launch-datetime-max-minute", "n_blur_timestamp"),
    State("launch-datetime-max-minute", "value"),
    Input("launch-datetime-step", "n_blur_timestamp"),
    State("launch-datetime-step", "value"),
    Input("radio-ascent-rate-type", "value"),
    Input("ascent-rate-input-min", "n_blur_timestamp"),
    State("ascent-rate-input-min", "value"),
    Input("ascent-rate-input-max", "n_blur_timestamp"),
    State("ascent-rate-input-max", "value"),
    Input("ascent-rate-input-step", "n_blur_timestamp"),
    State("ascent-rate-input-step", "value"),
    Input("ascent-rate-smoothed-initial", "n_blur_timestamp"),
    State("ascent-rate-smoothed-initial", "value"),
    Input("ascent-rate-slowing-rate", "n_blur_timestamp"),
    State("ascent-rate-slowing-rate", "value"),
    Input("ascent-rate-slowing-rate-bin", "n_blur_timestamp"),
    State("ascent-rate-slowing-rate-bin", "value"),
    Input("float-altitude-input-min", "n_blur_timestamp"),
    State("float-altitude-input-min", "value"),
    Input("float-altitude-input-max", "n_blur_timestamp"),
    State("float-altitude-input-max", "value"),
    Input("float-altitude-input-step", "n_blur_timestamp"),
    State("float-altitude-input-step", "value"),
    Input("float-duration-input-min", "n_blur_timestamp"),
    State("float-duration-input-min", "value"),
    Input("float-duration-input-max", "n_blur_timestamp"),
    State("float-duration-input-max", "value"),
    Input("float-duration-input-step", "n_blur_timestamp"),
    State("float-duration-input-step", "value"),
    Input("descent-rate-input", "n_blur_timestamp"),
    State("descent-rate-input", "value"),
    Input("camera-enable", "value"),
    Input("camera-degrees-fov-long-side", "n_blur_timestamp"),
    State("camera-degrees-fov-long-side", "value"),
    Input("camera-degrees-fov-short-side", "n_blur_timestamp"),
    State("camera-degrees-fov-short-side", "value"),
    Input("camera-pixels-long-side", "n_blur_timestamp"),
    State("camera-pixels-long-side", "value"),
    Input("camera-pixels-short-side", "n_blur_timestamp"),
    State("camera-pixels-short-side", "value"),
    Input("camera-side", "value"),
    Input("camera-frequency-ascent-descent-mins", "n_blur_timestamp"),
    State("camera-frequency-ascent-descent-mins", "value"),
    Input("camera-frequency-float-mins", "n_blur_timestamp"),
    State("camera-frequency-float-mins", "value"),
    Input("camera-opacity", "n_blur_timestamp"),
    State("camera-opacity", "value"),
    State("low-bandwidth-mode", "value"),
)
def update_params(
        latitude_input_n_blur,
        latitude_value: Optional[float],
        longitude_input_n_blur,
        longitude_value: Optional[float],
        latlon_step_input_n_blur,
        latlon_step_value: Optional[float],
        latlon_step_num_input_n_blur,
        latlon_step_num_value: Optional[int],
        altitude_min_input_n_blur,
        altitude_min: Optional[float],
        altitude_max_input_n_blur,
        altitude_max: Optional[float],
        altitude_step_input_n_blur,
        altitude_step: Optional[float],
        launch_datetime_min_date_str: Optional[str],
        launch_datetime_min_hour_input_n_blur,
        launch_datetime_min_hour: Optional[int],
        launch_datetime_min_minute_input_n_blur,
        launch_datetime_min_minute: Optional[int],
        launch_datetime_max_date_str: Optional[str],
        launch_datetime_max_hour_input_n_blur,
        launch_datetime_max_hour: Optional[int],
        launch_datetime_max_minute_input_n_blur,
        launch_datetime_max_minute: Optional[int],
        launch_datetime_step_input_n_blur,
        launch_datetime_step: Optional[str],
        ascent_rate_type: str,
        ascent_rate_min_input_n_blur,
        ascent_rate_min: Optional[float],
        ascent_rate_input_n_blur,
        ascent_rate_max: Optional[float],
        ascent_rate_step_input_n_blur,
        ascent_rate_step: Optional[float],
        ascent_rate_smoothed_initial_n_blur,
        ascent_rate_smoothed_initial: Optional[float],
        ascent_rate_slowing_rate_n_blur,
        ascent_rate_slowing_rate: Optional[float],
        ascent_rate_slowing_rate_bin_n_blur,
        ascent_rate_slowing_rate_bin: Optional[float],
        float_altitude_min_input_n_blur,
        float_altitude_min: Optional[float],
        float_altitude_input_n_blur,
        float_altitude_max: Optional[float],
        float_altitude_step_input_n_blur,
        float_altitude_step: Optional[float],
        float_duration_min_input_n_blur,
        float_duration_min: Optional[float],
        float_duration_max_input_n_blur,
        float_duration_max: Optional[float],
        float_duration_step_input_n_blur,
        float_duration_step: Optional[float],
        descent_rate_input_n_blur,
        descent_rates_raw: str,
        camera_enable,
        camera_degrees_fov_long_side_n_blur,
        camera_degrees_fov_long_side,
        camera_degrees_fov_short_side_n_blur,
        camera_degrees_fov_short_side,
        camera_pixels_long_side_n_blur,
        camera_pixels_long_side,
        camera_pixels_short_side_n_blur,
        camera_pixels_short_side,
        camera_side,
        camera_frequency_float_mins_n_blur,
        camera_frequency_float_mins,
        camera_frequency_ascent_descent_mins_n_blur,
        camera_frequency_ascent_descent_mins,
        camera_opacity_n_blur,
        camera_opacity,
        low_bandwidth_mode,
):
    errs = []
    display_latlon_map = True
    latitudes = [latitude_value or constants.DEFAULT_LATITUDE]
    if latitude_value is None:
        errs.append("Center latitude must be between -90.0 and 90.0")
        display_latlon_map = False
    if (
            latitude_value is not None
            and latlon_step_value is not None
            and latlon_step_num_value is not None
            and latlon_step_num_value > 0
    ):
        latitudes = np.linspace(
            latitude_value - latlon_step_value * latlon_step_num_value,
            latitude_value + latlon_step_value * latlon_step_num_value,
            latlon_step_num_value * 2 + 1,
        ).tolist()

    longitudes = [longitude_value or constants.DEFAULT_LONGITUDE]
    if longitude_value is None:
        errs.append("Center longitude must be between -180.0 and 360.0")
        display_latlon_map = False
    if (
            longitude_value is not None
            and latlon_step_value is not None
            and latlon_step_num_value is not None
            and latlon_step_num_value > 0
    ):
        longitudes = np.linspace(
            longitude_value - latlon_step_value * latlon_step_num_value,
            longitude_value + latlon_step_value * latlon_step_num_value,
            latlon_step_num_value * 2 + 1,
        ).tolist()

    if latlon_step_value is None or latlon_step_value <= 0:
        errs.append("Lat/lon step size must be > 0")
        display_latlon_map = False
    if latlon_step_num_value is None or latlon_step_num_value < 0:
        errs.append("Lat/lon steps from center must be an integer >= 0")
        display_latlon_map = False

    if display_latlon_map:
        latlon_map_fig = get_latlon_map(latitudes, longitudes)
        if low_bandwidth_mode:
            latlon_map = render_figure_as_image(latlon_map_fig, width=200, height=200)
        else:
            latlon_map = dcc.Graph(figure=latlon_map_fig)
    else:
        latlon_map = no_update

    altitudes = None
    if altitude_min is not None and altitude_max is not None:
        altitudes = [altitude_min]
        if altitude_max < altitude_min:
            errs.append("Max launch altitude must be >= min launch altitude")
        else:
            if altitude_max != altitude_min:
                if altitude_step is None or altitude_step <= 0:
                    errs.append(
                        "Launch altitude step must be > 0 if max launch altitude > min launch altitude"
                    )
                else:
                    altitudes = np.arange(
                        altitude_min, altitude_max, altitude_step
                    ).tolist() + [altitude_max]
    elif (altitude_min is None and altitude_max is not None) or (
            altitude_min is not None and altitude_max is None
    ):
        errs.append("Min and max launch altitudes must both be provided, or blank")

    float_altitudes = [float_altitude_min]
    if float_altitude_max < float_altitude_min:
        errs.append("Max float altitude must be >= min float altitude")
    else:
        if float_altitude_min != float_altitude_max:
            if float_altitude_step is None or float_altitude_step <= 0:
                errs.append(
                    "Float altitude step must be > 0 if max float altitude > min float altitude"
                )
            else:
                float_altitudes = np.arange(
                    float_altitude_min, float_altitude_max, float_altitude_step
                ).tolist() + [float_altitude_max]

    fixed_ascent_rates = None
    smoothed_ascent_rate = None

    if ascent_rate_type == "Fixed":
        fixed_ascent_rates = [
            ascent_rate_min or ascent_rate_max or constants.DEFAULT_ASCENT_RATE
        ]
        if ascent_rate_min is None:
            errs.append("Min ascent rate must be >= 0")
        if ascent_rate_max is None:
            errs.append("Max ascent rate must be >= 0")

        if ascent_rate_min is not None and ascent_rate_max is not None:
            if ascent_rate_max < ascent_rate_min:
                errs.append("Max ascent rate must be >= min ascent rate")
            else:
                if ascent_rate_min != ascent_rate_max:
                    if ascent_rate_step is None or ascent_rate_step <= 0:
                        errs.append(
                            "Ascent rate step must be > 0 if max ascent rate > min ascent rate"
                        )
                    else:
                        fixed_ascent_rates = np.arange(
                            ascent_rate_min, ascent_rate_max, ascent_rate_step
                        ).tolist() + [ascent_rate_max]

    else:
        if ascent_rate_smoothed_initial is None or ascent_rate_smoothed_initial <= 0:
            errs.append("Initial ascent rate must be > 0")
        if ascent_rate_slowing_rate is None or ascent_rate_slowing_rate <= 0:
            errs.append("Ascent rate slowing rate must be >= 0")
        if ascent_rate_slowing_rate_bin is None or ascent_rate_slowing_rate_bin <= 0:
            errs.append("Ascent rate slowing rate 'per X meters' must be > 0")

        smoothed_ascent_rate = input_tables.SmoothedAscentRate(
            initial_rate=ascent_rate_smoothed_initial,
            slowing_rate_m_s=ascent_rate_slowing_rate,
            slowing_rate_bin_m=ascent_rate_slowing_rate_bin,
        )

    descent_rates_raw = str(descent_rates_raw)
    if descent_rates_raw:
        try:
            descent_rates = [float(v) for v in descent_rates_raw.split(",") if v != ""]
            if any(v <= 0 for v in descent_rates) or not descent_rates:
                errs.append(
                    "Descent rates must be a comma-separated list of values > 0"
                )
        except ValueError:
            errs.append("Descent rates must be a comma-separated list of values > 0")
    else:
        errs.append("Descent rates must be a comma-separated list of values > 0")
        descent_rates = [constants.DEFAULT_DESCENT_RATE]

    default_datetime = constants.get_default_launch_time()
    launch_datetimes = [default_datetime]
    launch_datetime_min_str = "Pacific: " + default_datetime.astimezone(
        constants.LOCAL_TZ
    ).strftime(constants.LOCAL_TZ_FORMAT)
    launch_datetime_max_str = "Pacific: " + default_datetime.astimezone(
        constants.LOCAL_TZ
    ).strftime(constants.LOCAL_TZ_FORMAT)

    launch_datetime_min_dt = default_datetime
    launch_datetime_max_dt = default_datetime

    min_date_input_errors = False
    if launch_datetime_min_date_str is None:
        errs.append("Min launch date is invalid")
        min_date_input_errors = True
    if launch_datetime_min_hour is None:
        errs.append("Min launch hour must be between 0 and 23")
        min_date_input_errors = True
    if launch_datetime_min_minute is None:
        errs.append("Min launch minute must be between 0 and 59")
        min_date_input_errors = True

    if not min_date_input_errors:
        try:
            launch_datetime_min_date = datetime.date.fromisoformat(
                launch_datetime_min_date_str
            )
            launch_datetime_min_time = datetime.time(
                hour=launch_datetime_min_hour, minute=launch_datetime_min_minute
            )
            launch_datetime_min_dt = datetime.datetime.combine(
                date=launch_datetime_min_date,
                time=launch_datetime_min_time,
                tzinfo=datetime.timezone.utc,
            )
            launch_datetime_min_str = "Pacific: " + launch_datetime_min_dt.astimezone(
                constants.LOCAL_TZ
            ).strftime(constants.LOCAL_TZ_FORMAT)
        except ValueError:
            errs.append("Check that min launch date/hour/minute are valid")

    max_date_input_errors = False
    if launch_datetime_max_date_str is None:
        errs.append("Max launch date is invalid")
        max_date_input_errors = True
    if launch_datetime_max_hour is None:
        errs.append("Max launch hour must be between 0 and 23")
        max_date_input_errors = True
    if launch_datetime_max_minute is None:
        errs.append("Max launch minute must be between 0 and 59")
        max_date_input_errors = True

    if not max_date_input_errors:
        try:
            launch_datetime_max_date = datetime.date.fromisoformat(
                launch_datetime_max_date_str
            )
            launch_datetime_max_time = datetime.time(
                hour=launch_datetime_max_hour, minute=launch_datetime_max_minute
            )
            launch_datetime_max_dt = datetime.datetime.combine(
                date=launch_datetime_max_date,
                time=launch_datetime_max_time,
                tzinfo=datetime.timezone.utc,
            )
            launch_datetime_max_str = "Pacific: " + launch_datetime_max_dt.astimezone(
                constants.LOCAL_TZ
            ).strftime(constants.LOCAL_TZ_FORMAT)
        except ValueError:
            errs.append("Check that max launch date/hour/minute are valid")

    if launch_datetime_min_dt > launch_datetime_max_dt:
        errs.append("Min launch datetime must be <= max launch datetime")
    else:
        try:
            launch_datetimes = (
                pd.date_range(
                    start=launch_datetime_min_dt,
                    end=launch_datetime_max_dt,
                    freq=launch_datetime_step,
                )
                .to_pydatetime()
                .tolist()
            )
        except Exception as e:
            errs.append(f"Error calculating launch datetimes. Traceback: {e}")

    float_durations = [
        float_duration_min
        or float_duration_max
        or constants.DEFAULT_FLOAT_DURATION_MINUTES
    ]
    if float_duration_min is None or float_duration_min < 0:
        errs.append("Min float duration must be >= 0")
    if float_duration_max is None or float_duration_max < 0:
        errs.append("Max float duration must be >= 0")

    if float_duration_min is not None and float_duration_max is not None:
        if float_duration_max < float_duration_min:
            errs.append("Max float duration must be >= min float duration")
        else:
            if float_duration_min != float_duration_max:
                if float_duration_step is None or float_duration_step <= 0:
                    errs.append(
                        "Float duration step must be > 0 if max float duration > min float duration"
                    )
                else:
                    float_durations = np.arange(
                        float_duration_min, float_duration_max, float_duration_step
                    ).tolist() + [float_duration_max]

    if camera_enable:
        if camera_degrees_fov_long_side is None or camera_degrees_fov_long_side < 1:
            errs.append("Camera degrees FOV (long side) must be >= 1")
        if camera_degrees_fov_short_side is None or camera_degrees_fov_short_side < 1:
            errs.append("Camera degrees FOV (short side) must be >= 1")
        if camera_pixels_long_side is None or camera_pixels_long_side < 1:
            errs.append("Camera pixels (long side) must be >= 1")
        if camera_pixels_short_side is None or camera_pixels_short_side < 1:
            errs.append("Camera pixels (short side) must be >= 1")
        if not camera_side:
            errs.append("At least 1 camera side must be selected")
        if (
                camera_frequency_ascent_descent_mins is None
                or camera_frequency_ascent_descent_mins < 1
        ):
            errs.append(
                "Camera plot frequency - Initial Ascent/Descent (minutes) must be >= 1"
            )
        if camera_frequency_float_mins is None or camera_frequency_float_mins < 1:
            errs.append("Camera plot frequency - Float (minutes) must be >= 1")
        if camera_opacity is None or camera_opacity < 0 or camera_opacity > 1:
            errs.append("Camera plot opacity must be between 0.0 and 1.0")

    if errs:
        return (
            common.render_error_message_container_style(errs),
            common.render_error_list("Input validation errors", errs),
            no_update,
            no_update,
            no_update,
            latlon_map,
            common.render_latlon_map_style(display_latlon_map),
        )

    new_multifloat_container = input_tables.EnsembleContainer.from_ensemble_inputs(
        launch_latitudes=latitudes,
        launch_longitudes=longitudes,
        launch_datetimes=launch_datetimes,
        fixed_ascent_rates=fixed_ascent_rates,
        smoothed_ascent_rate=smoothed_ascent_rate,
        float_altitudes=float_altitudes,
        float_durations=float_durations,
        final_descent_rates=descent_rates,
        launch_altitudes=altitudes,
    ).to_dash()
    new_multifloat_div_children = [
        new_multifloat_container,
    ]

    return (
        common.render_error_message_container_style(errs),
        common.render_error_list("Input validation errors", errs),
        new_multifloat_div_children,
        launch_datetime_min_str,
        launch_datetime_max_str,
        latlon_map,
        common.render_latlon_map_style(display_latlon_map),
    )


@app.callback(
    Output("show-hide-table", "style"),
    State("show-hide-table", "style"),
    Input({"type": "show-hide-table-btn", "index": ALL}, "n_clicks"),
    prevent_initial_call=True,
)
def show_hide_table(current_style, btn_n_clicks):
    if current_style["display"] == "none":
        return {"display": "block"}
    else:
        return {"display": "none"}


@app.callback(
    Output("color-swatches", "style"),
    State("color-swatches", "style"),
    Input("show-hide-color-swatches-btn", "n_clicks"),
    prevent_initial_call=True,
)
def show_hide_color_swatches(current_style, btn_n_clicks):
    if current_style["display"] == "none":
        return {"display": "block"}
    else:
        return {"display": "none"}


@app.callback(
    Output("camera-inputs-fieldset", "style"),
    Input("camera-enable", "value"),
    prevent_initial_call=True,
)
def show_hide_camera_inputs(camera_enable_value):
    if camera_enable_value:
        return {"display": "block"}
    else:
        return {"display": "none"}


@app.callback(
    Output("show-fixed-ascent-rate-inputs", "style"),
    Output("show-smoothed-ascent-rate-inputs", "style"),
    Input("radio-ascent-rate-type", "value"),
)
def switch_ascent_rate_input_type(ascent_rate_type):
    if ascent_rate_type == "Fixed":
        return {"display": "block"}, {"display": "none"}
    else:
        return {"display": "none"}, {"display": "block"}


@app.callback(
    Output("flight-ensemble-table-multifloat-container", "children"),
    Output("upload-parameters-table", "contents"),
    Output("upload-parameters-table", "filename"),
    State("flight-ensemble-table-multifloat-container", "children"),
    Input("flight-ensemble-table-multifloat", "data_timestamp"),
    Input("add-row-table-multifloat-btn", "n_clicks"),
    Input("add-float-config-table-btn", "n_clicks"),
    Input("upload-parameters-table", "contents"),
    State("upload-parameters-table", "filename"),
    prevent_initial_call=True,
)
def update_tables(
        input_tables_container_children,
        input_tables_container_timestamp,
        add_row_multifloat_btn_n_clicks,
        add_float_config_btn_n_clicks,
        upload_contents,
        upload_filenames,
):
    if ctx.triggered_id == "add-row-table-multifloat-btn":
        ensemble_container = input_tables.EnsembleContainer.from_dash(input_tables_container_children)
        ensemble_container.add_launch_config_row()
        return (
            ensemble_container.to_dash(),
            no_update,
            no_update,
        )
    elif ctx.triggered_id == "flight-ensemble-table-multifloat":
        ensemble_container = input_tables.EnsembleContainer.from_dash(input_tables_container_children)
        ensemble_container.refresh_launch_config_options()
        return (
            ensemble_container.to_dash(),
            no_update,
            no_update,
        )
    elif ctx.triggered_id == "add-float-config-table-btn":
        ensemble_container = input_tables.EnsembleContainer.from_dash(input_tables_container_children)
        ensemble_container.add_float_config()
        return (
            ensemble_container.to_dash(),
            no_update,
            no_update,
        )
    elif ctx.triggered_id == "upload-parameters-table":
        if upload_contents is None:
            return no_update, None, None

        float_configs = []
        multifloat_table_cols = [
            c["id"] for c in input_tables.LaunchConfig(data=[]).to_dash().columns
        ]
        float_config_cols = [
            c["id"]
            for c in input_tables.FloatConfig(
                float_config_id="1", available_launch_config_ids=["1"]
            )
            .to_dash()
            .children[7]
            .columns
        ]

        multifloat_idx = [
            idx
            for idx, filename in enumerate(upload_filenames)
            if "float_config" not in filename
        ][0]
        multifloat_contents = upload_contents[multifloat_idx]

        content_type, content_string = multifloat_contents.split(",")
        bytes_obj = base64.b64decode(content_string)
        multifloat_df = pd.read_csv(
            io.StringIO(bytes_obj.decode("utf-8")),
            usecols=multifloat_table_cols,
        )
        if len(multifloat_df.index) == 0:
            return no_update, None, None
        multifloat_ids = multifloat_df["flight_profile_id"].unique().tolist()
        multifloat_data = multifloat_df.to_dict(orient="records")
        multifloat_table = input_tables.LaunchConfig(data=multifloat_data)

        raw_float_configs = [
            (idx, val)
            for idx, val in enumerate(upload_contents)
            if "float_config" in upload_filenames[idx]
        ]
        for idx, contents in raw_float_configs:
            filename = upload_filenames[idx]
            content_type, content_string = contents.split(",")
            bytes_obj = base64.b64decode(content_string)
            float_config_id = re.match("float_config_(.*).csv", filename).group(1)
            df = pd.read_csv(
                io.StringIO(bytes_obj.decode("utf-8")), usecols=float_config_cols
            )
            if len(df.index) > 0:
                data = df.to_dict(orient="records")
                float_config = input_tables.FloatConfig(
                    float_config_id=float_config_id,
                    available_launch_config_ids=multifloat_ids,
                    data=data,
                )
                float_configs.append(float_config)

        if len(float_configs) == 0:
            float_configs = [
                input_tables.FloatConfig(
                    float_config_id="1", available_launch_config_ids=multifloat_ids
                )
            ]
        return (
            input_tables.EnsembleContainer(
                launch_config=multifloat_table, float_configs=float_configs
            ).to_dash(),
            None,
            None,
        )
    return no_update, no_update, no_update


@app.callback(
    Output({"type": "flight-ensemble-table-multifloat-config", "index": MATCH}, "data"),
    Input({"type": "float-config-add-row-btn", "index": MATCH}, "n_clicks"),
    Input({"type": "float-config-default-dropdown", "index": MATCH}, "value"),
    State({"type": "flight-ensemble-table-multifloat-config", "index": MATCH}, "data"),
    prevent_initial_call=True,
)
def update_float_config(btn_n_clicks, dropdown_value, table_data):
    if "float-config-add-row-btn" in [
        v["type"] for v in ctx.triggered_prop_ids.values()
    ]:
        return table_data + [
            {
                "altitude": "",
                "ascent_descent_rate": "",
                "float_duration": "",
            }
        ]
    else:
        return input_tables.DEFAULT_FLOAT_CONFIGS[dropdown_value]


def format_hours_minutes_seconds(minutes):
    try:
        days = int(minutes / 60 / 24)
        hours = int((minutes - 60 * 24 * days) / 60)
        minutes_rem = int(minutes % 60)
    except TypeError:
        return None

    if days > 0:
        if hours > 0:
            return f"{days}d {hours}h {minutes_rem}m"
        else:
            return f"{days}d {minutes_rem}m"
    elif hours > 0:
        return f"{hours}h {minutes_rem}m"
    else:
        return None


@app.callback(
    Output("float-duration-input-min-pretty", "children"),
    Input("float-duration-input-min", "value"),
)
def format_float_duration_input_min(minutes):
    return format_hours_minutes_seconds(minutes)


@app.callback(
    Output("float-duration-input-max-pretty", "children"),
    Input("float-duration-input-max", "value"),
)
def format_float_duration_input_max(minutes):
    return format_hours_minutes_seconds(minutes)


@app.callback(
    Output("float-duration-input-step-pretty", "children"),
    Input("float-duration-input-step", "value"),
)
def format_float_duration_input_step(minutes):
    return format_hours_minutes_seconds(minutes)
