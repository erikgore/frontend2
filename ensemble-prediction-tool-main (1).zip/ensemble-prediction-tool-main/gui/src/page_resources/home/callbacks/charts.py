import pandas as pd
import plotly.express as px
from dash import Input, Output, State, get_app, dcc

from components.ensemble_parameters import colors
from page_resources.home.callbacks.util import render_figure_as_image

app = get_app()


@app.callback(
    Output("tawhiri-ensemble-chart-altitude-time", "children"),
    Input("tawhiri-ensemble-df-json", "data"),
    Input("color-palette-dropdown", "value"),
    Input("color-palette-reverse", "value"),
    State("low-bandwidth-mode", "value"),
    prevent_initial_call=True,
)
def get_chart_altitude_time(
        df_json, color_palette_str, color_palette_reverse, low_bandwidth_mode
):
    df = pd.read_json(df_json, orient="records")

    num_colors = df["Flight Profile"].unique().size
    palette = colors.get_color_from_name(
        color_palette_str, num_colors, color_palette_reverse
    )

    try:
        chart = px.line(
            df,
            x="Datetime",
            y="Altitude (m)",
            color="Flight Profile",
            title="Altitude vs Time",
            color_discrete_sequence=palette,
        )
    except ValueError:
        # Hack to retry generating the chart
        # See https://community.plotly.com/t/valueerror-invalid-value-in-basedatatypes-py/55993/8
        chart = px.line(
            df,
            x="Datetime",
            y="Altitude (m)",
            color="Flight Profile",
            title="Altitude vs Time",
            color_discrete_sequence=palette,
        )

    if low_bandwidth_mode:
        img = render_figure_as_image(chart, width=1555, height=450)
        return img
    else:
        return dcc.Graph(figure=chart)


@app.callback(
    Output("tawhiri-ensemble-chart-vertical-speed", "children"),
    Input("tawhiri-ensemble-df-json", "data"),
    Input("color-palette-dropdown", "value"),
    Input("color-palette-reverse", "value"),
    State("low-bandwidth-mode", "value"),
    prevent_initial_call=True,
)
def get_chart_vertical_speed(
        df_json, color_palette_str, color_palette_reverse, low_bandwidth_mode
):
    df = pd.read_json(df_json, orient="records")

    num_colors = df["Flight Profile"].unique().size
    palette = colors.get_color_from_name(
        color_palette_str, num_colors, color_palette_reverse
    )

    try:
        chart = px.line(
            df,
            x="Datetime",
            y="Vertical Speed (m/s)",
            color="Flight Profile",
            title="Vertical Speed",
            color_discrete_sequence=palette,
        )
    except ValueError:
        # Hack to retry generating the chart
        # See https://community.plotly.com/t/valueerror-invalid-value-in-basedatatypes-py/55993/8
        chart = px.line(
            df,
            x="Datetime",
            y="Vertical Speed (m/s)",
            color="Flight Profile",
            title="Vertical Speed",
            color_discrete_sequence=palette,
        )
    if low_bandwidth_mode:
        img = render_figure_as_image(chart, width=1555, height=450)
        return img
    else:
        return dcc.Graph(figure=chart)


@app.callback(
    Output("tawhiri-ensemble-chart-horizontal-speed", "children"),
    Input("tawhiri-ensemble-df-json", "data"),
    Input("color-palette-dropdown", "value"),
    Input("color-palette-reverse", "value"),
    State("low-bandwidth-mode", "value"),
    prevent_initial_call=True,
)
def get_chart_horizontal_speed(
        df_json, color_palette_str, color_palette_reverse, low_bandwidth_mode
):
    df = pd.read_json(df_json, orient="records")

    num_colors = df["Flight Profile"].unique().size
    palette = colors.get_color_from_name(
        color_palette_str, num_colors, color_palette_reverse
    )

    try:
        chart = px.line(
            df,
            x="Datetime",
            y="Horizontal Speed (m/s)",
            color="Flight Profile",
            title="Horizontal Speed",
            color_discrete_sequence=palette,
        )
    except ValueError:
        # Hack to retry generating the chart
        # See https://community.plotly.com/t/valueerror-invalid-value-in-basedatatypes-py/55993/8
        chart = px.line(
            df,
            x="Datetime",
            y="Horizontal Speed (m/s)",
            color="Flight Profile",
            title="Horizontal Speed",
            color_discrete_sequence=palette,
        )

    if low_bandwidth_mode:
        img = render_figure_as_image(chart, width=1555, height=450)
        return img
    else:
        return dcc.Graph(figure=chart)


@app.callback(
    Output("tawhiri-ensemble-chart-solar-angle-altitude", "children"),
    Input("tawhiri-ensemble-df-json", "data"),
    Input("color-palette-dropdown", "value"),
    Input("color-palette-reverse", "value"),
    State("low-bandwidth-mode", "value"),
    prevent_initial_call=True,
)
def get_chart_solar_angle_altitude(
        df_json, color_palette_str, color_palette_reverse, low_bandwidth_mode
):
    df = pd.read_json(df_json, orient="records")

    num_colors = df["Flight Profile"].unique().size
    palette = colors.get_color_from_name(
        color_palette_str, num_colors, color_palette_reverse
    )

    try:
        chart = px.line(
            df,
            x="Datetime",
            y="Solar Angle (Altitude)",
            title="Solar Altitude (degrees above horizon)",
            color="Flight Profile",
            color_discrete_sequence=palette,
        )
    except ValueError:
        # Hack to retry generating the chart
        # See https://community.plotly.com/t/valueerror-invalid-value-in-basedatatypes-py/55993/8
        chart = px.line(
            df,
            x="Datetime",
            y="Solar Angle (Altitude)",
            title="Solar Altitude (degrees above horizon)",
            color="Flight Profile",
            color_discrete_sequence=palette,
        )

    if low_bandwidth_mode:
        img = render_figure_as_image(chart, width=1555, height=450)
        return img
    else:
        return dcc.Graph(figure=chart)


@app.callback(
    Output("tawhiri-ensemble-chart-total-distance", "children"),
    Input("tawhiri-ensemble-df-json", "data"),
    Input("color-palette-dropdown", "value"),
    Input("color-palette-reverse", "value"),
    State("low-bandwidth-mode", "value"),
    prevent_initial_call=True,
)
def get_chart_total_distance(
        df_json, color_palette_str, color_palette_reverse, low_bandwidth_mode
):
    df = pd.read_json(df_json, orient="records")

    num_colors = df["Flight Profile"].unique().size
    palette = colors.get_color_from_name(
        color_palette_str, num_colors, color_palette_reverse
    )

    try:
        chart = px.line(
            df,
            x="Datetime",
            y="Total Distance From Start (km)",
            color="Flight Profile",
            title="Total Distance From Start (km) vs Time",
            color_discrete_sequence=palette,
        )
    except ValueError:
        # Hack to retry generating the chart
        # See https://community.plotly.com/t/valueerror-invalid-value-in-basedatatypes-py/55993/8
        chart = px.line(
            df,
            x="Datetime",
            y="Total Distance From Start (km)",
            color="Flight Profile",
            title="Total Distance From Start (km) vs Time",
            color_discrete_sequence=palette,
        )

    if low_bandwidth_mode:
        img = render_figure_as_image(chart, width=1555, height=450)
        return img
    else:
        return dcc.Graph(figure=chart)
