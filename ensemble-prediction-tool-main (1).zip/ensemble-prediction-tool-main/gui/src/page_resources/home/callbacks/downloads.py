import datetime
import io
import os
import subprocess
import tempfile
import zipfile
from dataclasses import dataclass
from typing import List

import jinja2
import pandas as pd
from dash import Input, Output, State, ctx, dcc, get_app, html

from components.ensemble_parameters import constants, input_tables
from components.util import get_safe_filename

app = get_app()


@dataclass
class ZippableFile:
    filename: str
    file_bytes: bytes


def generate_zip(files: List[ZippableFile]):
    mem_zip = io.BytesIO()

    with zipfile.ZipFile(mem_zip, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for f in files:
            zf.writestr(f.filename, f.file_bytes)

    return mem_zip.getvalue()


@app.callback(
    Output("download-parameters-table", "data"),
    Input("download-table-btn", "n_clicks"),
    State("flight-ensemble-table-multifloat-container", "children"),
    prevent_initial_call=True,
)
def download_parameter_tables(btn_n_clicks, multi_float_container):
    timestamp_str = datetime.datetime.now(tz=datetime.timezone.utc).strftime(
        "%Y%m%dT%H%M%S"
    )
    filename = f"multi_float_parameters_{timestamp_str}.zip"

    zip_files = []

    ensemble_container = input_tables.EnsembleContainer.from_dash(multi_float_container)

    # Ascent parameters
    launch_config_df = pd.DataFrame.from_records(ensemble_container.launch_config.data).set_index(
        "flight_profile_id"
    )
    launch_config_bytes = bytes(launch_config_df.to_csv(), encoding="utf-8")
    launch_config_file = ZippableFile(
        "multi_float_ascent_params.csv", file_bytes=launch_config_bytes
    )
    zip_files.append(launch_config_file)

    # Float configs
    for float_config in ensemble_container.float_configs:
        df = pd.DataFrame.from_records(float_config.data)
        float_config_bytes = bytes(df.to_csv(index=False), encoding="utf-8")
        float_config_file = ZippableFile(
            filename=f"float_config_{float_config.float_config_id}.csv",
            file_bytes=float_config_bytes,
        )
        zip_files.append(float_config_file)

    zip_file = generate_zip(zip_files)
    return dcc.send_bytes(zip_file, filename=filename)


@app.callback(
    Output("latest-csv-path", "data"),
    Input("tawhiri-ensemble-df-json", "data"),
    State("sim-name-input", "value"),
    prevent_initial_call=True,
)
def save_csv(df_json, sim_name):
    if not sim_name:
        timestamp_now = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        sim_name = f"flight-ensemble-{timestamp_now}"
    sim_name = get_safe_filename(sim_name)
    df = pd.read_json(df_json, orient="records")
    file_path = os.path.join(constants.DOWNLOADS_FOLDER, f"{sim_name}.csv")
    df.to_csv(file_path, index=False)

    latest_file_path = os.path.join(constants.DOWNLOADS_FOLDER, f"latest.csv")
    subprocess.check_call(["ln", "-sf", file_path, latest_file_path])

    return file_path


@app.callback(
    Output("tawhiri-ensemble-download-csv", "data"),
    State("tawhiri-ensemble-df-json", "data"),
    Input("tawhiri-ensemble-download-csv-btn", "n_clicks"),
    State("sim-name-input", "value"),
    prevent_initial_call=True,
)
def download_csv(df_json, n_clicks, sim_name):
    # Only run if the button was clicked (don't fire every time the underlying data changes)
    callback_triggered = ctx.triggered_id
    if callback_triggered == "tawhiri-ensemble-download-csv-btn":
        if not sim_name:
            timestamp_now = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            sim_name = f"flight-ensemble-{timestamp_now}"
        sim_name = get_safe_filename(sim_name)
        df = pd.read_json(df_json, orient="records")
        return dcc.send_data_frame(
            df.to_csv, f"flight-ensemble-{sim_name}.csv", index=False
        )


def gen_kml(df_json: str, sim_name: str) -> str:
    df = pd.read_json(df_json, orient="records")

    flights = []
    markers = []
    flight_ids = df["Flight Profile"].unique()
    for flight_id in flight_ids:
        points = df.loc[df["Flight Profile"] == flight_id]
        flights.append(
            {
                "flight_profile_id": flight_id,
                "points": points.to_dict(orient="records"),
            }
        )

        flight_start = points.iloc[0].to_dict()
        flight_end = points.iloc[-1].to_dict()
        start_marker = {
            "name": f"Flight Profile {flight_id}: Start",
            "description": flight_start["Datetime"],
            "point": {
                "lat": flight_start["Latitude"],
                "lon": flight_start["Longitude"],
                "alt": flight_start["Altitude (m)"],
            },
        }
        markers.append(start_marker)
        end_marker = {
            "name": f"Flight Profile {flight_id}: End",
            "description": flight_end["Datetime"],
            "point": {
                "lat": flight_end["Latitude"],
                "lon": flight_end["Longitude"],
                "alt": flight_end["Altitude (m)"],
            },
        }
        markers.append(end_marker)

    templates_dir = "/ensemble_predict/templates"
    jinja_env = jinja2.Environment(loader=jinja2.FileSystemLoader(templates_dir))
    template = jinja_env.get_template("template.kml")
    kml_output = template.render(
        sim_name=sim_name,
        flights=flights,
        markers=markers,
    )
    return kml_output


@app.callback(
    Output("latest-kml-path", "data"),
    Input("tawhiri-ensemble-df-json", "data"),
    State("sim-name-input", "value"),
    prevent_initial_call=True,
)
def save_kml(df_json, sim_name):
    if not sim_name:
        timestamp_now = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        sim_name = f"flight-ensemble-{timestamp_now}"
    sim_name = get_safe_filename(sim_name)
    kml_output = gen_kml(df_json, sim_name)
    file_path = os.path.join(constants.DOWNLOADS_FOLDER, f"{sim_name}.kml")
    with open(file_path, "w") as fp:
        fp.write(kml_output)

    latest_file_path = os.path.join(constants.DOWNLOADS_FOLDER, f"latest.kml")
    subprocess.check_call(["ln", "-sf", file_path, latest_file_path])

    return file_path


@app.callback(
    Output("tawhiri-ensemble-download-kml", "data"),
    State("tawhiri-ensemble-df-json", "data"),
    Input("tawhiri-ensemble-download-kml-btn", "n_clicks"),
    State("latest-kml-path", "data"),
    prevent_initial_call=True,
)
def download_kml(df_json, n_clicks, kml_path):
    # Only run if the button was clicked (don't fire every time the underlying data changes)
    callback_triggered = ctx.triggered_id
    if callback_triggered == "tawhiri-ensemble-download-kml-btn":
        return dcc.send_file(kml_path, type="kml")


@app.callback(
    output=dict(gps_progress_message=Output("gps-progress-message", "children")),
    state=dict(df_json=State("tawhiri-ensemble-df-json", "data"),
               sim_name=State("sim-name-input", "value")),
    inputs=dict(download_gps_n_clicks=Input("tawhiri-ensemble-download-gps-btn", "n_clicks"),
                download_gps_inputs_n_clicks=Input("tawhiri-ensemble-download-gps-inputs-btn", "n_clicks")),
    progress=[Output("download-gps-progress-div", "style"), Output("gps-progress-message", "children")],
    prevent_initial_call=True,
    background=True,
)
def download_simulated_gps_files(set_progress, df_json, sim_name, download_gps_n_clicks, download_gps_inputs_n_clicks):
    if not sim_name:
        timestamp_now = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        sim_name = f"flight-ensemble-{timestamp_now}"
    sim_name = get_safe_filename(sim_name)

    zip_files = []

    df = pd.read_json(df_json, orient="records")
    # The Tawhiri API gives longitude in the range 0 to 360.
    # The GPS sim application expects longitude in the range -180 to +180.
    df["Longitude"] = df["Longitude"] - 180

    sample_rate_hz = 10
    sample_rate_seconds = 1 / sample_rate_hz
    resample_str = f"{sample_rate_seconds}S"

    gnss_dir = os.getenv("GNSS_DIR", "/gnss_data")
    gnss_file = os.path.join(gnss_dir, "brdc")

    file_prefix = f"gps_sim_inputs_{sim_name}"

    with tempfile.TemporaryDirectory() as tempdir:
        for flight_profile_name, flight_profile_df in df.groupby("Flight Profile"):
            safe_flight_profile_name = get_safe_filename(flight_profile_name)
            zip_files.append(gnss_file)

            resampled = (
                flight_profile_df.resample(resample_str, on="Datetime")
                .first()
                .reset_index()
                .fillna(method="ffill")
            )
            start_time = resampled.at[0, "Datetime"]
            resampled["Time since start"] = resampled["Datetime"] - start_time
            resampled["Time since start (s)"] = resampled["Time since start"].dt.total_seconds()

            # Save the flight path CSV to disk
            csv_path = os.path.join(tempdir, f"flight_path_{safe_flight_profile_name}.csv")
            app.logger.info("Saving lat/lon/alt data for flight profile %s to %s", flight_profile_name, csv_path)
            set_progress(({"display": "block"}, f"Saving lat/lon/alt data to CSV for {flight_profile_name}"))
            resampled.to_csv(csv_path,
                             index=False,
                             header=False,
                             columns=["Time since start (s)", "Latitude", "Longitude", "Altitude (m)"])
            zip_files.append(csv_path)

            if ctx.triggered_id == "tawhiri-ensemble-download-gps-btn":
                file_prefix = f"gps_sim_data_{sim_name}"
                gps_sim_file = os.path.join(tempdir, f"gpssim_{safe_flight_profile_name}.bin")
                app.logger.info("Generating simulated GPS NMEA data for flight profile %s at %s", flight_profile_name,
                                gps_sim_file)
                set_progress(({"display": "block"}, f"Generating simulated GPS data for {flight_profile_name}"))
                subprocess.check_call(
                    ["/gps-sdr-sim/gps-sdr-sim", "-b", "8", "-e", gnss_file, "-x", csv_path, "-o", gps_sim_file])

                app.logger.info("File size for flight profile %s - %s bytes", flight_profile_name,
                                os.stat(gps_sim_file).st_size)

                zip_files.append(gps_sim_file)

        filename = f"{file_prefix}.zip"
        zip_file = os.path.join(constants.DOWNLOADS_FOLDER, filename)
        zip_command = ["zip", "-j", zip_file] + zip_files

        app.logger.info(f"Zipping {len(zip_files)} files into {zip_file}")
        set_progress(({"display": "block"}, f"Zipping {len(zip_files)} files"))
        subprocess.check_call(zip_command)

        file_url = f"/file_downloads/{filename}"
        file_link = html.Div(
            children=[
                "Download file at ",
                html.A(
                    file_url,
                    href=file_url,
                ),
                " or ",
                html.A(
                    "Show all downloadable files",
                    href="/file_downloads",
                ),
            ]
        ),
        return dict(gps_progress_message=file_link)
