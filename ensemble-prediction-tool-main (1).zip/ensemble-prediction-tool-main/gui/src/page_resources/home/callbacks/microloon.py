from dash import Input, Output, no_update, get_app

from components.ensemble_parameters import common, microloon

app = get_app()


@app.callback(
    Output("microloon-device-dropdown", "options"),
    Output("microloon-device-dropdown-store", "data"),
    Output("microloon-dropdown-errors", "style"),
    Output("microloon-dropdown-errors", "children"),
    Input("microloon-device-dropdown-interval", "n_intervals"),
)
def refresh_microloon_device_dropdown(n_intervals):
    try:
        flight_names = microloon.get_recent_flight_names()
        return flight_names, flight_names, common.render_error_message_container_style(False), None
    except microloon.InfluxError as e:
        return no_update, no_update, common.render_error_message_container_style(True), str(e)


@app.callback(
    Output("microloon-div", "style"),
    Output("microloon-device-dropdown-interval", "disabled"),
    Output("microloon-position-refresh", "value"),
    Input("microloon-input-checkbox", "value"),
    prevent_initial_call=True
)
def show_hide_microloon_input(checkbox_value):
    if checkbox_value:
        return {"display": "block"}, False, ["Refresh"]
    else:
        return {"display": "none"}, True, []


@app.callback(
    Output("microloon-position-store", "data"),
    Output("microloon-position-info", "children"),
    Output("microloon-position-errors", "style"),
    Output("microloon-position-errors", "children"),
    Input("microloon-device-dropdown", "value"),
    prevent_initial_call=True
)
def get_latest_microloon_data(dropdown_value):
    if dropdown_value:
        try:
            position = microloon.get_latest_position_for_flight(dropdown_value)
            return position.to_json(), position.to_dash(), common.render_error_message_container_style(False), None
        except microloon.InfluxError as e:
            return no_update, no_update, common.render_error_message_container_style(True), str(e)

    return no_update, no_update, no_update, no_update


@app.callback(
    Output("microloon-position-refresh-interval", "disabled"),
    Input("microloon-position-refresh", "value"),
    prevent_initial_call=True
)
def enable_microloon_position_refresh(checkbox_value):
    # If checked, do refresh (i.e. disabled = False)
    if checkbox_value:
        return False
    else:
        return True
