from dash import dcc, html

import tawhiri
from components import util
from components.ensemble_parameters import (
    constants,
    common,
    input_tables
)


def get_initial_layout():
    return html.Div(
        children=[
            html.H1("Ensemble Flight Prediction"),
            html.Div(
                children=[
                    f"Uses the tawhiri prediction model at {tawhiri.BASE_TAWHIRI_URL}",
                    html.A(
                        "(API Docs)",
                        href="https://tawhiri.readthedocs.io/en/latest/api.html",
                        style={"padding-left": "5px"},
                    ),
                ]
            ),
            html.Div(
                id="rate-limiting",
                children=[
                    "Rate limiting: " + "Enabled"
                    if tawhiri.APPLY_RATE_LIMIT
                    else "Rate limiting: Disabled"
                ],
            ),
            html.Div(id="latest-gfs-dataset-message"),
            dcc.Store(id="latest-gfs-dataset-datetime"),
            dcc.Interval(
                id="latest-gfs-dataset-interval",
                interval=60 * 1000,  # in milliseconds
                n_intervals=0,
            ),
            html.Div(
                id="mapbox-token",
                children=[
                    "Mapbox token found"
                    if constants.MAPBOX_TOKEN
                    else "Mapbox token not found"
                ],
            ),
            html.Div(
                id="app-version-number",
                children=f"App version: {util.get_app_version()}",
            ),
            html.A(
                "Show all downloadable files",
                href="/file_downloads",
            ),
            html.Br(),
            html.H2("Parameters"),
            html.Label(
                "Sim Name", htmlFor="sim-name-input"
            ),
            dcc.Input(id="sim-name-input", persistence=True),
            dcc.Store(id="latest-kml-path"),
            dcc.Store(id="latest-csv-path"),
            html.Br(),
            html.Br(),
            dcc.Checklist(id="low-bandwidth-mode", options=[{
                "label": "Low bandwidth mode (render charts/maps on server as images)",
                "value": "Enabled"
            }], value=[], persistence=True),
            html.Br(),
            dcc.Checklist(id="microloon-input-checkbox",
                          options=[
                              {
                                  "label": "Set inputs from latest microloon (lat/lon, launch altitude, launch time)",
                                  "value": "Show",
                              },
                          ],
                          value=[],
                          persistence=True),
            html.Br(),
            html.Div(id="microloon-div", style={"display": "none"}, children=[
                html.Br(),
                "Select a microloon device",
                dcc.Dropdown(id="microloon-device-dropdown", options=[], persistence=True),
                dcc.Store(id="microloon-device-dropdown-store"),
                dcc.Interval(
                    id="microloon-device-dropdown-interval",
                    interval=5 * 60 * 1000,  # in milliseconds
                ),
                dcc.Store(id="microloon-position-store"),
                dcc.Interval(
                    id="microloon-position-refresh-interval",
                    interval=30 * 1000,  # in milliseconds
                ),
                html.Br(),
                dcc.Checklist(id="microloon-position-refresh",
                              options=[
                                  {
                                      "label": "Auto-refresh (every 30s)",
                                      "value": "Refresh",
                                  },
                              ],
                              value=["Refresh"],
                              persistence=True),
                html.Div(id="microloon-position-info"),
                html.Div(id="microloon-dropdown-errors", style={"display": "none"}),
                html.Div(id="microloon-position-errors", style={"display": "none"}),
                html.Br()
            ]),
            html.Button(
                "Reset parameters",
                id="reset-parameters-btn",
                className="btn"
            ),
            html.Br(),
            html.Br(),
            html.Div(
                id="input-form-container",
                children=[
                    common.EnsembleFormInputs().to_dash(),
                ],
            ),
            html.Div(
                id="input-validation-errors", style={"display": "none"}, children=[]
            ),
            html.Div(
                id="input-validation-warnings", style={"display": "none"}, children=[]
            ),
            html.Br(),
            html.Button(
                "Show/Hide Table(s)", id={
                    "type": "show-hide-table-btn",
                    "index": "1",
                }, className="btn"
            ),
            html.Button(
                "Download Table(s)",
                id="download-table-btn",
                className="btn display:inline-block",
            ),
            dcc.Download(id="download-parameters-table"),
            html.Button(
                "Run ensemble",
                id="tawhiri-ensemble-run-btn",
                className="btn",
            ),
            html.Button("Regenerate Map", id="regenerate-map-btn", className="btn"),
            dcc.Upload(
                id="upload-parameters-table",
                multiple=True,
                children=[
                    "Upload Table(s): Drag and Drop or ",
                    html.A("Select a File"),
                ],
                style={
                    "width": "100%",
                    "height": "60px",
                    "lineHeight": "60px",
                    "borderWidth": "1px",
                    "borderStyle": "dashed",
                    "borderRadius": "5px",
                    "textAlign": "center",
                    "marginTop": "5px",
                },
            ),
            html.Div(
                id="show-hide-table",
                style={"display": "none"},
                children=[
                    html.Br(),
                    html.Div(
                        id="show-hide-table-multifloat",
                        children=[
                            input_tables.EnsembleContainer.from_ensemble_inputs(
                                launch_latitudes=[constants.DEFAULT_LATITUDE],
                                launch_longitudes=[constants.DEFAULT_LONGITUDE],
                                launch_altitudes=[constants.DEFAULT_LAUNCH_ALTITUDE],
                                launch_datetimes=[constants.get_default_launch_time()],
                                fixed_ascent_rates=[constants.DEFAULT_ASCENT_RATE],
                                smoothed_ascent_rate=input_tables.SmoothedAscentRate(
                                    initial_rate=constants.DEFAULT_ASCENT_RATE,
                                    slowing_rate_m_s=constants.DEFAULT_ASCENT_RATE_SLOWING_RATE,
                                    slowing_rate_bin_m=constants.DEFAULT_ASCENT_RATE_SLOWING_RATE_BIN,
                                ),
                                float_altitudes=[constants.DEFAULT_FLOAT_ALTITUDE],
                                float_durations=[
                                    constants.DEFAULT_FLOAT_DURATION_MINUTES
                                ],
                                final_descent_rates=[constants.DEFAULT_DESCENT_RATE],
                            ).to_dash(),
                        ],
                    ),
                    html.Button(
                        "Show/Hide Table(s)", id={
                            "type": "show-hide-table-btn",
                            "index": "2",
                        }, className="btn"
                    ),
                ],
            ),
            dcc.Store(id="tawhiri-ensemble-df-json"),
            html.Div(id="results-warnings", style={"display": "none"}, children=[]),
            html.Div(
                id="ensemble-progress-div",
                style={"display": "none"},
                children=[
                    html.H3("Sim Progress"),
                    html.Div(id="ensemble-progress-message"),
                    html.Progress(id="ensemble-progress-bar"),
                ],
            ),
            html.Div(
                id="show-hide-results",
                style={"display": "block"},
                children=[
                    html.Br(),
                    html.Button(
                        "Download Prediction CSV",
                        id="tawhiri-ensemble-download-csv-btn",
                        className="btn display:inline-block",
                    ),
                    html.Button(
                        "Download Prediction KML",
                        id="tawhiri-ensemble-download-kml-btn",
                        className="btn display:inline-block",
                    ),
                    html.Button(
                        "Run/Download GPS Sim",
                        id="tawhiri-ensemble-download-gps-btn",
                        className="btn display:inline-block",
                    ),
                    html.Button(
                        "Download GPS Sim Inputs",
                        id="tawhiri-ensemble-download-gps-inputs-btn",
                        className="btn display:inline-block",
                    ),
                    html.Div(
                        id="download-gps-progress-div",
                        style={"display": "none"},
                        children=[
                            html.H3("GPS Sim Progress"),
                            html.Div(id="gps-progress-message"),
                        ],
                    ),
                    html.Div(
                        id="map-progress-div",
                        style={"display": "none"},
                        children=[
                            html.H3("Map Progress"),
                            html.Div(id="map-progress-message-camera"),
                            html.Progress(id="map-progress-bar-camera"),
                        ],
                    ),
                    dcc.Loading(id="tawhiri-ensemble-map-loading"),
                    html.Div(
                        id="wind-map-progress-div",
                        style={"display": "none"},
                        children=[
                            html.H3("Wind Map Progress"),
                            html.Div(id="wind-map-progress-message"),
                            html.Progress(id="wind-map-progress-bar"),
                        ],
                    ),
                    html.Div(id="wind-quiver-map-div",
                             style={"display": "none"},
                             children=[html.H3("GFS Wind Speeds"),
                                       dcc.Tabs(id="wind-quiver-tabs")]),
                    html.Div(id="tawhiri-ensemble-chart-altitude-time"),
                    html.Div(id="tawhiri-ensemble-chart-vertical-speed"),
                    html.Div(id="tawhiri-ensemble-chart-horizontal-speed"),
                    html.Div(id="tawhiri-ensemble-chart-solar-angle-altitude"),
                    html.Div(id="tawhiri-ensemble-chart-total-distance"),
                    dcc.Download(id="tawhiri-ensemble-download-csv"),
                    dcc.Download(id="tawhiri-ensemble-download-kml"),
                ],
            ),
        ]
    )
