import logging

import plotly.express as px

from app import app
from components.ensemble_parameters.constants import MAPBOX_TOKEN

# Some mapbox map styles need a Mapbox API token (some don't).
# See the latest docs at https://plotly.com/python-api-reference/generated/plotly.express.line_mapbox
if MAPBOX_TOKEN:
    px.set_mapbox_access_token(MAPBOX_TOKEN)

server = app.server

if __name__ == "__main__":
    # Run Flask debug server
    app.logger.setLevel(logging.INFO)
    app.run(host="0.0.0.0", port=8050, debug=True)

if __name__ != "__main__":
    # Run Gunicorn server - attach gunicorn logging handlers to Flask handlers
    # so Flask logs get redirected properly.
    gunicorn_logger = logging.getLogger("gunicorn.error")
    app.logger.handlers = gunicorn_logger.handlers
    app.logger.setLevel(gunicorn_logger.level)
