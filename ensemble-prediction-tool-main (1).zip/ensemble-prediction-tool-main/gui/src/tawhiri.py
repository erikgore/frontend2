import datetime
import math
import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from functools import wraps
from typing import List, Optional

import pandas as pd
import pysolar
import requests
from dash import get_app
from dateutil.parser import isoparse
from geopy import distance
from requests.adapters import HTTPAdapter
from urllib3 import Retry

app = get_app()

# API Docs: https://tawhiri.readthedocs.io/en/latest/api.html
DEFAULT_BASE_TAWHIRI_URL = "https://api.v2.sondehub.org"
BASE_TAWHIRI_URL = os.getenv("TAWHIRI_API_URL", DEFAULT_BASE_TAWHIRI_URL)
# Global request rate limit - only apply if using the SondeHub Tawhiri URL
APPLY_RATE_LIMIT = os.getenv("APPLY_RATE_LIMIT", "True").lower() in (
    "true",
    "1",
    "t",
    "y",
    "yes",
)
SECONDS_BETWEEN_REQUESTS = 1
LAST_REQUEST_TIMESTAMP = time.time()


class PredictionType(Enum):
    STANDARD = "standard"
    FLOAT = "float"


def apply_rate_limit(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        # Global request rate limit
        global APPLY_RATE_LIMIT
        global LAST_REQUEST_TIMESTAMP
        global SECONDS_BETWEEN_REQUESTS
        if (
                APPLY_RATE_LIMIT
                and SECONDS_BETWEEN_REQUESTS is not None
                and SECONDS_BETWEEN_REQUESTS > 0
        ):
            time_now = time.time()
            seconds_since_last_request = time_now - LAST_REQUEST_TIMESTAMP
            if seconds_since_last_request < SECONDS_BETWEEN_REQUESTS:
                time.sleep(SECONDS_BETWEEN_REQUESTS - seconds_since_last_request)
        res = f(*args, **kwargs)
        LAST_REQUEST_TIMESTAMP = time.time()
        return res

    return wrapper


class TawhiriException(Exception):
    pass


class PredictionInputsException(Exception):
    pass


@apply_rate_limit
def make_tawhiri_request(prediction_type: PredictionType, params: dict) -> pd.DataFrame:
    # The SondeHub Tawhiri API only exposes a /tawhiri endpoint (corresponding to /api/v1 in the Tawhiri Flask app)
    # If TAWHIRI_API_URL env var is set to a custom instance of the Tawhiri API, we need to use the /api/v1 endpoint.
    tawhiri_url = f"{BASE_TAWHIRI_URL}/api/v1"
    if BASE_TAWHIRI_URL == DEFAULT_BASE_TAWHIRI_URL:
        tawhiri_url = f"{BASE_TAWHIRI_URL}/tawhiri"

    app.logger.info(
        f"Fetching {prediction_type.value} flight prediction from URL {tawhiri_url} : {params}"
    )
    session = requests.Session()
    adapter = HTTPAdapter(max_retries=Retry(total=4, backoff_factor=1))
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    res = session.get(tawhiri_url, params=params)

    try:
        res.raise_for_status()
    except requests.HTTPError:
        try:
            error_json = res.json()
        except requests.JSONDecodeError:
            error_msg = f"Error decoding response JSON (status {res.status_code}): {res.text}"
            app.logger.error(error_msg)
            raise TawhiriException(error_msg)
        app.logger.error(f"Error JSON: {error_json}")
        if (
                "error" in error_json
                and error_json["error"]["type"] == "PredictionException"
        ):
            error_msg = error_json["error"]["description"]
            raise TawhiriException(error_msg)
        else:
            res.raise_for_status()

    try:
        tawhiri_response = res.json()
    except requests.JSONDecodeError:
        error_msg = f"Error decoding response JSON (status {res.status_code}): {res.text}"
        app.logger.error(error_msg)
        raise TawhiriException(error_msg)

    # Parse JSON into a DataFrame
    df = None
    for stage_data in tawhiri_response["prediction"]:
        stage_name = stage_data["stage"]
        stage_df = pd.DataFrame.from_records(stage_data["trajectory"])
        stage_df["stage"] = stage_name
        if df is None:
            df = stage_df
        else:
            df = pd.concat([df, stage_df])

    df["datetime"] = pd.to_datetime(df["datetime"])
    app.logger.debug(df)
    return df


class GFSException(Exception):
    pass


class GFSEndpointNotFoundException(GFSException):
    pass


class GFSDatasetNotFoundException(GFSException):
    pass


@dataclass
class GFSInfo:
    dataset_timestamp: datetime.datetime
    forecast_hours: int

    def to_dash_json(self):
        return {"dataset_timestamp": self.dataset_timestamp.isoformat(),
                "forecast_hours": self.forecast_hours}

    @staticmethod
    def from_dash_json(d: dict):
        return GFSInfo(dataset_timestamp=isoparse(d["dataset_timestamp"]),
                       forecast_hours=d["forecast_hours"])


@apply_rate_limit
def get_gfs_info() -> Optional[GFSInfo]:
    # The SondeHub Tawhiri API only exposes a /tawhiri endpoint and does not expose a /api/datasetcheck endpoint.
    # So we can effectively only get the GFS timestamp when using our own Tawhiri API
    tawhiri_url = f"{BASE_TAWHIRI_URL}/api/datasetcheck"
    if BASE_TAWHIRI_URL == DEFAULT_BASE_TAWHIRI_URL:
        raise GFSEndpointNotFoundException

    app.logger.info(f"Fetching GFS dataset metadata via URL {tawhiri_url}")
    session = requests.Session()
    adapter = HTTPAdapter(max_retries=Retry(total=4, backoff_factor=1))
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    res = session.get(tawhiri_url)
    try:
        res.raise_for_status()
    except requests.HTTPError:
        error_json = res.json()
        app.logger.error(f"Error JSON: {error_json}")
        if (
                "error" in error_json
                and error_json["error"]["type"] == "InvalidDatasetException"
        ):
            raise GFSDatasetNotFoundException

    tawhiri_response = res.json()
    gfs_timestamp = isoparse(tawhiri_response["request"]["dataset"])
    gfs_forecast_hours = tawhiri_response["request"]["forecast_hours"]
    gfs_info = GFSInfo(dataset_timestamp=gfs_timestamp,
                       forecast_hours=gfs_forecast_hours)
    return gfs_info


class RuaumokoException(Exception):
    pass


def get_altitude_m_agl(altitude_m_msl: float, latitude: float, longitude: float):
    tawhiri_url = f"{BASE_TAWHIRI_URL}/api/ruaumoko"
    if BASE_TAWHIRI_URL == DEFAULT_BASE_TAWHIRI_URL:
        raise RuaumokoException

    params = {"latitude": latitude, "longitude": longitude}
    app.logger.info(f"Fetching altitude mAGL via URL {tawhiri_url}")
    session = requests.Session()
    adapter = HTTPAdapter(max_retries=Retry(total=4, backoff_factor=1))
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    res = session.get(tawhiri_url, params=params)
    try:
        res.raise_for_status()
    except requests.HTTPError:
        error_json = res.json()
        app.logger.error(f"Error JSON: {error_json}")
        raise RuaumokoException(error_json)

    tawhiri_response = res.json()
    ground_altitude = tawhiri_response["altitude"]
    return max(0, altitude_m_msl - ground_altitude)


class WindSpeedException(Exception):
    pass


def chunks(lst, n):
    """Yield successive n-sized chunks from lst."""
    for i in range(0, len(lst), n):
        yield lst[i:i + n]


def get_wind_speeds(request_dicts: List[dict]):
    tawhiri_url = f"{BASE_TAWHIRI_URL}/api/wind"
    if BASE_TAWHIRI_URL == DEFAULT_BASE_TAWHIRI_URL:
        raise WindSpeedException

    output_df = pd.DataFrame()
    chunk_size = 10000
    num_chunks = math.ceil(len(request_dicts) / chunk_size)
    chunk_counter = 1
    for chunk in chunks(request_dicts, chunk_size):
        app.logger.info(f"Fetching wind speeds via URL {tawhiri_url} (chunk {chunk_counter} of {num_chunks})")
        session = requests.Session()
        adapter = HTTPAdapter(max_retries=Retry(total=4, backoff_factor=1))
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        res = session.post(tawhiri_url, json=chunk)
        try:
            res.raise_for_status()
        except requests.HTTPError:
            error_json = res.json()
            app.logger.error(f"Error JSON: {error_json}")
            raise WindSpeedException(error_json)
        tawhiri_response = res.json()
        wind_speeds = tawhiri_response["wind_speeds"]
        df = pd.DataFrame.from_records(wind_speeds)
        if chunk_counter == 1:
            output_df = df
        else:
            output_df = pd.concat([output_df, df])
        chunk_counter += 1
    return output_df


class TawhiriPrediction(ABC):
    def __init__(self, profile_id: str, launch_latitude: float, launch_longitude: float,
                 launch_altitude_m: Optional[float], launch_datetime: datetime.datetime):
        self.profile_id = profile_id
        self.launch_latitude = launch_latitude
        self.launch_longitude = launch_longitude
        self.launch_altitude_m = launch_altitude_m
        self.launch_datetime = launch_datetime

        self._base_validations()
        self._adjust_launch_longitude()

    @abstractmethod
    def get_flight_path(self) -> pd.DataFrame:
        pass

    def _adjust_launch_longitude(self):
        if (
                self.launch_longitude < 0
        ):  # If using -180 to +180 range, convert to 0 to 360 range
            self.launch_longitude = self.launch_longitude % 360

    def _base_validations(self):
        if not -90.0 < self.launch_latitude < 90.0:
            raise PredictionInputsException("Launch latitude must be between -90 and 90")
        if not -180.0 < self.launch_longitude < 360.0:
            raise PredictionInputsException("Launch longitude must be between -180 and 360")
        if not self.launch_datetime.tzinfo:
            raise PredictionInputsException("Launch datetime must include a timezone")


@dataclass
class StandardPrediction(TawhiriPrediction):
    """
    A simple ascent followed immediately by a burst and descent (no float time)
    """

    profile_id: str
    launch_latitude: float
    launch_longitude: float
    launch_altitude_m: Optional[float]
    launch_datetime: datetime.datetime
    ascent_rate_ms: float
    burst_altitude_m: float
    descent_rate_ms: float

    def __post_init__(self):
        super().__init__(profile_id=self.profile_id,
                         launch_latitude=self.launch_latitude,
                         launch_longitude=self.launch_longitude,
                         launch_altitude_m=self.launch_altitude_m,
                         launch_datetime=self.launch_datetime)
        self._validate_inputs()
        self.request_params = {
            "profile": "standard_profile",
            "launch_latitude": self.launch_latitude,
            "launch_longitude": self.launch_longitude,
            "launch_datetime": self.launch_datetime.isoformat(timespec="seconds"),
            "ascent_rate": self.ascent_rate_ms,
            "burst_altitude": self.burst_altitude_m,
            "descent_rate": self.descent_rate_ms,
        }
        if self.launch_altitude_m is not None:
            self.request_params["launch_altitude"] = self.launch_altitude_m

    def _validate_inputs(self):
        # Various validations
        if self.ascent_rate_ms <= 0.0:
            raise PredictionInputsException("Ascent rate must be > 0")
        if self.launch_altitude_m is not None and self.burst_altitude_m <= self.launch_altitude_m:
            raise PredictionInputsException("Burst altitude must be > launch altitude")
        if self.descent_rate_ms <= 0.0:
            raise PredictionInputsException("Descent rate must be > 0")

    def get_flight_path(self) -> pd.DataFrame:
        return make_tawhiri_request(PredictionType.STANDARD, self.request_params)


@dataclass
class FloatPrediction(TawhiriPrediction):
    """
    An ascent followed by a float at altitude, forecasted to a given datetime. No predictions for the descent.
    """

    profile_id: str
    launch_latitude: float
    launch_longitude: float
    launch_altitude_m: Optional[float]
    launch_datetime: datetime.datetime
    ascent_rate_ms: float
    float_altitude_m: float
    stop_datetime: datetime.datetime

    def __post_init__(self):
        super().__init__(profile_id=self.profile_id,
                         launch_latitude=self.launch_latitude,
                         launch_longitude=self.launch_longitude,
                         launch_altitude_m=self.launch_altitude_m,
                         launch_datetime=self.launch_datetime)
        self._validate_inputs()
        self.request_params = {
            "profile": "float_profile",
            "launch_latitude": self.launch_latitude,
            "launch_longitude": self.launch_longitude,
            "launch_datetime": self.launch_datetime.isoformat(timespec="seconds"),
            "ascent_rate": self.ascent_rate_ms,
            "float_altitude": self.float_altitude_m,
            "stop_datetime": self.stop_datetime.isoformat(timespec="seconds"),
        }
        if self.launch_altitude_m is not None:
            self.request_params["launch_altitude"] = self.launch_altitude_m

    def _validate_inputs(self):
        # Various validations
        if self.ascent_rate_ms <= 0.0:
            raise PredictionInputsException("Ascent rate must be > 0")
        if self.launch_altitude_m is not None and self.float_altitude_m <= self.launch_altitude_m:
            raise PredictionInputsException("Float altitude must be > launch altitude")
        if self.stop_datetime <= self.launch_datetime:
            raise PredictionInputsException("Stop datetime must be > launch datetime")
        if not self.stop_datetime.tzinfo:
            raise PredictionInputsException("Stop datetime must have a timezone")

    def get_flight_path(self) -> pd.DataFrame:
        return make_tawhiri_request(PredictionType.FLOAT, self.request_params)


@dataclass
class FloatConfig:
    float_altitude_m: float
    ascent_descent_rate_ms: float
    float_duration: float


@dataclass
class MultiFloatPrediction(TawhiriPrediction):
    """
    An ascent followed by multiple float periods at various altitudes, followed by a descent.
    """

    profile_id: str
    original_profile_id: str
    float_config_id: str
    launch_latitude: float
    launch_longitude: float
    launch_altitude_m: Optional[float]
    launch_datetime: datetime.datetime
    float_configs: List[FloatConfig]
    final_descent_rate_ms: float

    def __post_init__(self):
        super().__init__(profile_id=self.profile_id,
                         launch_latitude=self.launch_latitude,
                         launch_longitude=self.launch_longitude,
                         launch_altitude_m=self.launch_altitude_m,
                         launch_datetime=self.launch_datetime)
        self._validate_inputs()

    def _validate_inputs(self):
        # Float config validations
        for fc in self.float_configs:
            if fc.float_duration < 0.0:
                raise PredictionInputsException("Float duration must be >= 0")
            if self.launch_altitude_m is not None:
                if fc.float_altitude_m <= self.launch_altitude_m:
                    raise PredictionInputsException("Float altitude must be > launch altitude")

    def get_flight_path(self) -> pd.DataFrame:
        flight_path = None
        for float_config_idx in range(0, len(self.float_configs)):
            fc = self.float_configs[float_config_idx]
            ascent_duration_seconds = fc.float_altitude_m / fc.ascent_descent_rate_ms
            if float_config_idx == 0:
                # Initial ascent
                # The ascent must be calculated separately instead of a plain float because we need to figure out a start/stop
                # time for the float that matches the float_duration.
                # Estimate the ascent duration (conservatively; actual will vary based on launch altitude)
                ascent_stop_datetime = self.launch_datetime + datetime.timedelta(
                    minutes=10, seconds=ascent_duration_seconds
                )
                ascent_pred = FloatPrediction(
                    profile_id=self.profile_id,
                    launch_latitude=self.launch_latitude,
                    launch_longitude=self.launch_longitude,
                    launch_altitude_m=self.launch_altitude_m,
                    launch_datetime=self.launch_datetime,
                    ascent_rate_ms=fc.ascent_descent_rate_ms,
                    float_altitude_m=fc.float_altitude_m,
                    stop_datetime=ascent_stop_datetime,
                )

                ascent_flight_path = ascent_pred.get_flight_path()
                ascent_flight_path = ascent_flight_path.loc[
                    ascent_flight_path["stage"] == "ascent"
                    ]
                last_row = ascent_flight_path.sort_values("datetime").iloc[-1]
                float_start_lat = last_row.latitude
                float_start_long = last_row.longitude
                float_start_alt = last_row.altitude
                float_start_datetime = last_row.datetime
                if fc.float_duration == 0:
                    timedelta = datetime.timedelta(seconds=1)
                else:
                    timedelta = datetime.timedelta(minutes=fc.float_duration)
                float_stop_datetime = float_start_datetime + timedelta
                initial_float_pred = FloatPrediction(
                    profile_id=self.profile_id,
                    launch_latitude=float_start_lat,
                    launch_longitude=float_start_long,
                    launch_altitude_m=float_start_alt,
                    launch_datetime=float_start_datetime,
                    ascent_rate_ms=fc.ascent_descent_rate_ms,
                    float_altitude_m=float_start_alt + 1,
                    stop_datetime=float_stop_datetime,
                )
                float_flight_path = initial_float_pred.get_flight_path()
                flight_path = pd.concat([ascent_flight_path, float_flight_path])
            else:
                # Not initial ascent. May be ascending or descending to new float altitude.
                prior_fc = self.float_configs[float_config_idx - 1]
                last_row = flight_path.sort_values("datetime").iloc[-1]
                start_lat = last_row.latitude
                start_long = last_row.longitude
                start_alt = last_row.altitude
                start_datetime = last_row.datetime

                ascent_descent_duration_seconds = (
                        abs(start_alt - fc.float_altitude_m) / fc.ascent_descent_rate_ms
                )
                ascent_descent_stop_datetime = start_datetime + datetime.timedelta(
                    minutes=10, seconds=ascent_descent_duration_seconds
                )

                if fc.float_altitude_m > prior_fc.float_altitude_m:
                    # Ascending to new float altitude
                    ascent_pred = FloatPrediction(
                        profile_id=self.profile_id,
                        launch_latitude=start_lat,
                        launch_longitude=start_long,
                        launch_altitude_m=start_alt,
                        launch_datetime=start_datetime,
                        ascent_rate_ms=fc.ascent_descent_rate_ms,
                        float_altitude_m=fc.float_altitude_m,
                        stop_datetime=ascent_descent_stop_datetime,
                    )

                    ascent_flight_path = ascent_pred.get_flight_path()
                    ascent_flight_path = ascent_flight_path.loc[
                        ascent_flight_path["stage"] == "ascent"
                        ]
                    last_row = ascent_flight_path.sort_values("datetime").iloc[-1]
                    float_start_lat = last_row.latitude
                    float_start_long = last_row.longitude
                    float_start_alt = last_row.altitude
                    float_start_datetime = last_row.datetime
                    if fc.float_duration == 0:
                        timedelta = datetime.timedelta(seconds=1)
                    else:
                        timedelta = datetime.timedelta(minutes=fc.float_duration)
                    float_stop_datetime = float_start_datetime + timedelta
                    float_pred = FloatPrediction(
                        profile_id=self.profile_id,
                        launch_latitude=float_start_lat,
                        launch_longitude=float_start_long,
                        launch_altitude_m=float_start_alt,
                        launch_datetime=float_start_datetime,
                        ascent_rate_ms=fc.ascent_descent_rate_ms,
                        float_altitude_m=float_start_alt + 1,
                        stop_datetime=float_stop_datetime,
                    )
                    float_pred_path = float_pred.get_flight_path()
                    flight_path = pd.concat(
                        [flight_path, ascent_flight_path, float_pred_path]
                    )
                else:
                    # Descending to a new float altitude
                    descent_pred = StandardPrediction(
                        profile_id=self.profile_id,
                        launch_latitude=start_lat,
                        launch_longitude=start_long,
                        launch_altitude_m=start_alt,
                        launch_datetime=start_datetime,
                        ascent_rate_ms=fc.ascent_descent_rate_ms,
                        burst_altitude_m=start_alt + 1,  # Must be > launch_altitude_m
                        descent_rate_ms=fc.ascent_descent_rate_ms,
                    )
                    descent_flight_path = descent_pred.get_flight_path()

                    # Remove artifact of ascending to "burst" altitude
                    descent_flight_path = descent_flight_path.loc[
                        (descent_flight_path["stage"] == "descent")
                        & (descent_flight_path["altitude"] >= fc.float_altitude_m)
                        & (descent_flight_path["altitude"] < start_alt)
                        ]

                    flight_path = pd.concat([flight_path, descent_flight_path])

                    # Floating at the new altitude
                    last_row = flight_path.sort_values("datetime").iloc[-1]
                    start_lat = last_row.latitude
                    start_long = last_row.longitude
                    start_alt = last_row.altitude
                    start_datetime = last_row.datetime
                    if fc.float_duration == 0:
                        timedelta = datetime.timedelta(seconds=1)
                    else:
                        timedelta = datetime.timedelta(minutes=fc.float_duration)
                    float_stop_datetime = start_datetime + timedelta
                    float_alt = fc.float_altitude_m
                    if start_alt >= float_alt:
                        float_alt = (
                                start_alt + 1
                        )  # Float altitude must be > launch altitude

                    float_pred = FloatPrediction(
                        profile_id=self.profile_id,
                        launch_latitude=start_lat,
                        launch_longitude=start_long,
                        launch_altitude_m=start_alt,
                        launch_datetime=start_datetime,
                        ascent_rate_ms=fc.ascent_descent_rate_ms,
                        float_altitude_m=float_alt,
                        stop_datetime=float_stop_datetime,
                    )
                    float_pred_path = float_pred.get_flight_path()
                    flight_path = pd.concat([flight_path, float_pred_path])

        last_row = flight_path.sort_values("datetime").iloc[-1]
        start_lat = last_row.latitude
        start_long = last_row.longitude
        start_alt = last_row.altitude
        start_datetime = last_row.datetime
        descent_pred = StandardPrediction(
            profile_id=self.profile_id,
            launch_latitude=start_lat,
            launch_longitude=start_long,
            launch_altitude_m=start_alt,
            launch_datetime=start_datetime,
            ascent_rate_ms=self.final_descent_rate_ms,
            burst_altitude_m=start_alt + 1,  # Must be > launch_altitude_m
            descent_rate_ms=self.final_descent_rate_ms,
        )
        descent_flight_path = descent_pred.get_flight_path()

        # Remove artifact of ascending to "burst" altitude
        descent_flight_path = descent_flight_path.loc[
            (descent_flight_path["stage"] == "descent")
            & (descent_flight_path["altitude"] < start_alt)
            ]

        flight_path = pd.concat([flight_path, descent_flight_path])
        flight_path["Flight Profile (Original)"] = self.original_profile_id
        flight_path["Float Config ID"] = self.float_config_id

        return flight_path


def calc_vertical_speed(row):
    if row["Datetime Change (s)"] > 0:
        return row["Altitude Change"] / row["Datetime Change (s)"]


def calc_horizontal_speed(row):
    if (
            pd.notna(row["Previous Latitude"])
            and pd.notna(row["Previous Longitude"])
            and row["Datetime Change (s)"] > 0
    ):
        return (
                distance.distance(
                    (row["Previous Latitude"], row["Previous Longitude"]),
                    (row["latitude"], row["longitude"]),
                ).meters
                / row["Datetime Change (s)"]
        )


def get_ensemble_df_from_dict_input(d: dict) -> pd.DataFrame:
    time_format = "%Y-%m-%dT%H:%M:%S.%fZ"
    launch_datetime = datetime.datetime.strptime(
        d["launch_datetime"], time_format
    )
    d["altitude"] = d["altitude"] or None
    float_configs = []
    for fc_dict in d["float_configs"]:
        fc = FloatConfig(
            float_altitude_m=fc_dict["altitude"],
            ascent_descent_rate_ms=fc_dict["ascent_descent_rate"],
            float_duration=fc_dict["float_duration"],
        )
        float_configs.append(fc)

    flight_profile = MultiFloatPrediction(
        profile_id=d["flight_profile_id"],
        original_profile_id=d["flight_profile_id_original"],
        float_config_id=d["float_config_id"],
        launch_latitude=d["latitude"],
        launch_longitude=d["longitude"],
        launch_altitude_m=d["altitude"],
        launch_datetime=launch_datetime,
        float_configs=float_configs,
        final_descent_rate_ms=d["descent_rate"],
    )

    flight_path = flight_profile.get_flight_path()

    flight_path["Flight Profile"] = flight_profile.profile_id
    flight_path["Launch Altitude (m)"] = flight_profile.launch_altitude_m
    flight_path["Launch Latitude"] = flight_profile.launch_latitude
    flight_path["Launch Longitude"] = flight_profile.launch_longitude
    flight_path["Launch Time"] = flight_profile.launch_datetime
    flight_path["Final Descent Rate (m/s)"] = flight_profile.final_descent_rate_ms

    flight_path["Total Distance From Start (km)"] = flight_path.apply(
        lambda row: distance.distance(
            (row["latitude"], row["longitude"]),
            (row["Launch Latitude"], row["Launch Longitude"]),
        ).km,
        axis=1,
    )
    flight_path["X Distance From Start (km)"] = flight_path.apply(
        lambda row: distance.distance(
            (row["Launch Latitude"], row["longitude"]),
            (row["Launch Latitude"], row["Launch Longitude"]),
        ).km,
        axis=1,
    )
    flight_path["Y Distance From Start (km)"] = flight_path.apply(
        lambda row: distance.distance(
            (row["latitude"], row["Launch Longitude"]),
            (row["Launch Latitude"], row["Launch Longitude"]),
        ).km,
        axis=1,
    )
    flight_path["Altitude Change"] = flight_path["altitude"].diff()
    flight_path["Datetime Change (s)"] = (
        flight_path["datetime"].diff().dt.total_seconds()
    )
    flight_path["Vertical Speed (m/s)"] = flight_path.apply(calc_vertical_speed, axis=1)
    flight_path["Previous Latitude"] = flight_path["latitude"].shift()
    flight_path["Previous Longitude"] = flight_path["longitude"].shift()
    flight_path["Horizontal Speed (m/s)"] = flight_path.apply(
        calc_horizontal_speed, axis=1
    )
    flight_path["Solar Angle (Altitude)"] = flight_path.apply(
        lambda row: pysolar.solar.get_altitude(
            row["latitude"], row["longitude"], row["datetime"].to_pydatetime()
        ),
        axis=1,
    )

    flight_path.rename(
        {
            "datetime": "Datetime",
            "altitude": "Altitude (m)",
            "latitude": "Latitude",
            "longitude": "Longitude",
            "stage": "Stage",
        },
        axis=1,
        inplace=True,
    )

    return flight_path
