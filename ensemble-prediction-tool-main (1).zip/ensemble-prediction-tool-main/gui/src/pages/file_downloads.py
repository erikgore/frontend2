import dash

from page_resources.file_downloads.callbacks import *  # noqa
from page_resources.file_downloads.layout import get_initial_layout

dash.register_page(__name__, path="/file_downloads", name="File Downloads")
layout = get_initial_layout()
