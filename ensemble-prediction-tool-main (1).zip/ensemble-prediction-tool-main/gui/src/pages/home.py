import dash

from page_resources.home.callbacks import *  # noqa
from page_resources.home.layout import get_initial_layout

dash.register_page(__name__, path="/", name="Ensemble Prediction Tool")
layout = get_initial_layout()
