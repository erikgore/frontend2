def get_app_version():
    with open("/VERSION", "r") as fp:
        return fp.readline()


def get_safe_filename(original_name: str):
    return "".join(c for c in original_name if c.isalnum() or c == "-")
