import plotly.express as px

QUALITATIVE_SWATCHES_FIG = px.colors.qualitative.swatches()
QUALITATIVE_COLOR_NAMES = sorted(
    [bar_fig.y[0] for bar_fig in QUALITATIVE_SWATCHES_FIG.data]
)

SEQUENTIAL_SWATCHES_FIG = px.colors.sequential.swatches_continuous()
SEQUENTIAL_COLOR_NAMES = sorted(
    [bar_fig.y[0] for bar_fig in SEQUENTIAL_SWATCHES_FIG.data]
)


def get_color_from_name(color_name: str, num_colors: int, reverse: bool = False):
    full_color_name = color_name + "_r" if reverse else color_name

    if color_name in QUALITATIVE_COLOR_NAMES:
        return getattr(px.colors.qualitative, full_color_name)
    elif color_name in SEQUENTIAL_COLOR_NAMES:
        # By default, the px.colors.sequential.[full_color_name] will return a fixed-size palette of 10-15 colors.
        # To prevent colors repeating due to the limited palette, we can construct our own palette over the full range.
        palette = px.colors.sample_colorscale(
            full_color_name, [n / (num_colors - 1) for n in range(num_colors)]
        )
        return palette
    else:
        raise ValueError(
            f"Could not match color to any Plotly sequential/qualitative color palette: {color_name}"
        )
