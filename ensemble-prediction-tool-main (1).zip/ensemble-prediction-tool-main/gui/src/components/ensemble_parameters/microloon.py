"""
Pulls latest GPS (Microloon) position from InfluxDB
Contact Mike Licitra regarding access to the InfluxDB instance
"""

from dash import html
from dataclasses import dataclass, asdict
from influxdb import InfluxDBClient
import json
import os

CONNECTION_SETTINGS = {
    "INFLUX_HOST": os.getenv("INFLUX_HOST"),
    "INFLUX_PORT": int(os.getenv("INFLUX_PORT", "8086")),
    "INFLUX_DATABASE": os.getenv("INFLUX_DATABASE"),
    "INFLUX_USER": os.getenv("INFLUX_USER"),
    "INFLUX_PASSWORD": os.getenv("INFLUX_PASSWORD")
}


class InfluxError(Exception):
    pass


def assert_env_vars_set():
    errs = [k for k, v in CONNECTION_SETTINGS.items() if v is None]
    if errs:
        err_str = ", ".join(errs)
        raise InfluxError(f"Cannot connect to Influx database. Missing Influx environment variables: {err_str}")


def _run_query(query: str):
    assert_env_vars_set()
    client = InfluxDBClient(host=CONNECTION_SETTINGS["INFLUX_HOST"],
                            port=CONNECTION_SETTINGS["INFLUX_PORT"],
                            database=CONNECTION_SETTINGS["INFLUX_DATABASE"],
                            username=CONNECTION_SETTINGS["INFLUX_USER"],
                            password=CONNECTION_SETTINGS["INFLUX_PASSWORD"])
    return client.query(query)


@dataclass
class GPSPosition:
    latitude: float
    longitude: float
    altitude_m: float
    time_: str

    @staticmethod
    def from_result(result):
        pos_lat = list(result.get_points(measurement='gps/pos_lat'))[0]['last_value']
        pos_long = list(result.get_points(measurement='gps/pos_long'))[0]['last_value']
        pos_alt = list(result.get_points(measurement='gps/pos_alt'))[0]['last_value']
        pos_time = list(result.get_points(measurement='gps/pos_lat'))[0]['time']
        return GPSPosition(pos_lat, pos_long, pos_alt, pos_time)

    def to_dash(self):
        return [
            f"Latitude: {self.latitude}",
            html.Br(),
            f"Longitude: {self.longitude}",
            html.Br(),
            f"Altitude (m): {self.altitude_m}",
            html.Br(),
            f"Timestamp: {self.time_}",
        ]

    def to_json(self):
        return json.dumps(asdict(self))

    @staticmethod
    def from_json(s: str):
        data = json.loads(s)
        return GPSPosition(data["latitude"],
                           data["longitude"],
                           data["altitude_m"],
                           data["time_"])


def get_recent_flight_names(minutes_lookback: int = 72 * 60):
    try:
        query = f'SELECT LAST(*) FROM "gps/pos_lat" WHERE time > now() - {minutes_lookback}m AND time <= now() GROUP BY system'
        result = _run_query(query)
        names = sorted(set(tags["system"] for series_name, tags in result.keys()))
        return names
    except Exception as e:
        raise InfluxError(f"Error fetching microloon devices. Error: {e}")


def get_latest_position_for_flight(flight_name: str):
    try:
        query = f'SELECT LAST(*) FROM "gps/pos_lat","gps/pos_long","gps/pos_alt" WHERE time <= now() AND "system" =~ /^{flight_name}/'
        result = _run_query(query)
        return GPSPosition.from_result(result)
    except Exception as e:
        raise InfluxError(f"Error fetching latest position for microloon {flight_name}. Error: {e}")
