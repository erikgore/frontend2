import datetime
import os

import pandas as pd
import pytz

DEFAULT_ASCENT_RATE = 4.5
DEFAULT_ASCENT_RATE_STEP = 0.5

# Ascent rate slowing
# Slow down by 0.5 m/s for every 500m in altitude change
DEFAULT_ASCENT_RATE_SLOWING_RATE = 0.5
DEFAULT_ASCENT_RATE_SLOWING_RATE_BIN = 500

DEFAULT_DESCENT_RATE = 6
DEFAULT_DESCENT_RATE_STEP = 0.5
DEFAULT_LAUNCH_ALTITUDE = None
DEFAULT_BURST_ALTITUDE = 30000
DEFAULT_FLOAT_ALTITUDE = 22000  # Must be > DEFAULT_LAUNCH_ALTITUDE
DEFAULT_FLOAT_ALTITUDE_STEP = 1000
DEFAULT_LATITUDE = 37.0916
DEFAULT_LONGITUDE = -121.9059


def get_default_launch_time():
    return pd.Timestamp.now(datetime.timezone.utc).ceil("H").to_pydatetime()


DEFAULT_DATETIME_STEP = "24H"
LOCAL_TZ = pytz.timezone("US/Pacific")
LOCAL_TZ_FORMAT = "%Y-%m-%d %H:%M:%S"

# Default float duration
DEFAULT_FLOAT_DURATION_MINUTES = 60 * 5
DEFAULT_FLOAT_DURATION_STEP = 60

DOWNLOADS_FOLDER = os.getenv("DOWNLOADS_FOLDER", "/file_downloads")

MAPBOX_TOKEN = os.getenv("MAPBOX_TOKEN")
