from geopy.distance import distance, Point
import math
import numpy as np
from typing import List


class Camera:
    def __init__(
            self,
            fov_degrees: float,
            pixels: int,
    ):
        self.fov_degrees = fov_degrees
        self.pixels = pixels

        self.fov_radians = math.radians(self.fov_degrees)
        self.fov_radians_tan = math.tan(self.fov_radians)

        self.pixel_angle_radians = self.fov_radians / self.pixels
        self.pixel_angle_radians_tan = math.tan(self.pixel_angle_radians)

    def image_radius_m(self, altitude_m_agl: float):
        return self.fov_radians_tan * altitude_m_agl

    def avg_pixel_size_m(self, altitude_m_agl: float):
        return self.image_radius_m(altitude_m_agl) / self.pixels

    def nadir_pixel_size_m(self, altitude_m_agl: float):
        return self.pixel_angle_radians_tan * altitude_m_agl

    def get_image_corners(self,
                          altitude_m_agl: float,
                          latitude: float,
                          longitude: float,
                          num_points: int = 36) -> List[Point]:
        half_radius_m = self.image_radius_m(altitude_m_agl) / 2
        distance_to_corner_km = math.sqrt(2 * math.pow(half_radius_m, 2)) / 1000
        for angle in np.linspace(0, 359, num_points):
            corner = distance(kilometers=distance_to_corner_km).destination(
                (latitude, longitude), angle
            )
            yield corner
