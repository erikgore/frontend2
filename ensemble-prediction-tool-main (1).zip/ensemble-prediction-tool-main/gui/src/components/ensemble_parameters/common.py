from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional

from dash import dcc, html

from components.ensemble_parameters.colors import *
from components.ensemble_parameters.constants import *


@dataclass
class LatLonInputs:
    center_latitude: float = DEFAULT_LATITUDE
    center_longitude: float = DEFAULT_LONGITUDE
    step_size: float = 0.1
    num_steps_from_center: int = 0

    @staticmethod
    def from_dash(raw_dash: html.Fieldset):
        div_children = raw_dash["props"]["children"][1]["props"]["children"][0]["props"]["children"]
        center_latitude = div_children[1]["props"]["value"]
        center_longitude = div_children[4]["props"]["value"]
        step_size = div_children[7]["props"]["value"]
        num_steps_from_center = div_children[10]["props"]["value"]
        return LatLonInputs(center_latitude=center_latitude,
                            center_longitude=center_longitude,
                            step_size=step_size,
                            num_steps_from_center=num_steps_from_center)

    def to_dash(self):
        return html.Fieldset(
            children=[
                html.Legend("Launch Lat/Lon"),
                html.Div(
                    style={"display": "flex"},
                    children=[
                        html.Div(
                            [
                                html.Label(
                                    "Center Latitude", htmlFor="launch-latitude-input"
                                ),
                                dcc.Input(
                                    id="launch-latitude-input",
                                    value=self.center_latitude,
                                    type="number",
                                    min=-90.0,
                                    max=90.0,
                                    persistence=True
                                ),
                                html.Br(),
                                html.Label(
                                    "Center Longitude", htmlFor="launch-longitude-input"
                                ),
                                dcc.Input(
                                    id="launch-longitude-input",
                                    value=self.center_longitude,
                                    type="number",
                                    min=-180.0,
                                    max=360.0,
                                    persistence=True
                                ),
                                html.Br(),
                                html.Label("Step Size", htmlFor="launch-latlon-input-step"),
                                dcc.Input(
                                    id="launch-latlon-input-step",
                                    value=self.step_size,
                                    type="number",
                                    min=0.0,
                                    persistence=True
                                ),
                                html.Br(),
                                html.Label(
                                    "# Steps from Center",
                                    htmlFor="launch-latlon-input-step-num",
                                ),
                                dcc.Input(
                                    id="launch-latlon-input-step-num",
                                    value=self.num_steps_from_center,
                                    type="number",
                                    min=0,
                                    step=1,
                                    persistence=True
                                ),
                                html.Div(
                                    style={"font-size": "12px"},
                                    children=[
                                        html.Br(),
                                        "# Steps from Center will generate N points in 4 directions, starting from the center point.",
                                        html.Br(),
                                        "0 steps from center is a single point.",
                                        html.Br(),
                                        "1 step from center is a 3x3 grid.",
                                        html.Br(),
                                        "2 steps from center is a 5x5 grid.",
                                        html.Br(),
                                        "Step size is in degrees lat/lon.",
                                    ],
                                ),
                            ],
                        ),
                        html.Div(id="launch-latlon-map",
                                 style=render_latlon_map_style(display=False)),
                    ],
                ),
            ],
        )


@dataclass
class LaunchAltitudeInputs:
    launch_altitude_min: float = None
    launch_altitude_max: float = None
    launch_altitude_step: float = 0.0

    @staticmethod
    def from_dash(raw_dash: html.Fieldset):
        launch_altitude_min = raw_dash["props"]["children"][3]["props"]["value"]
        launch_altitude_max = raw_dash["props"]["children"][6]["props"]["value"]
        launch_altitude_step = raw_dash["props"]["children"][9]["props"]["value"]
        return LaunchAltitudeInputs(launch_altitude_min=launch_altitude_min,
                                    launch_altitude_max=launch_altitude_max,
                                    launch_altitude_step=launch_altitude_step)

    def to_dash(self):
        return html.Fieldset(
            children=[
                html.Legend("Launch Altitude (m)"),
                html.Div(
                    style={"font-size": "12px"},
                    children="If min/max are not provided, the model will use the ground height at the launch latitude/longitude.",
                ),
                html.Label("Min", htmlFor="launch-altitude-input-min"),
                dcc.Input(id="launch-altitude-input-min", type="number", value=self.launch_altitude_min,
                          persistence=True),
                html.Br(),
                html.Label("Max", htmlFor="launch-altitude-input-max"),
                dcc.Input(id="launch-altitude-input-max", type="number", value=self.launch_altitude_max,
                          persistence=True),
                html.Br(),
                html.Label("Step", htmlFor="launch-altitude-input-step"),
                dcc.Input(id="launch-altitude-input-step", type="number", min=0.0, value=self.launch_altitude_step,
                          persistence=True),
            ]
        )


@dataclass
class LaunchDatetimeInputs:
    min_launch_date: datetime.date = None
    min_launch_hour: int = None
    min_launch_minute: int = None
    max_launch_date: datetime.date = None
    max_launch_hour: int = None
    max_launch_minute: int = None
    launch_datetime_step: str = DEFAULT_DATETIME_STEP
    default_timestamp: datetime.datetime = field(init=False, repr=False, default_factory=get_default_launch_time)

    def __post_init__(self):
        if self.min_launch_date is None:
            self.min_launch_date = self.default_timestamp.date()
        if self.min_launch_hour is None:
            self.min_launch_hour = self.default_timestamp.hour
        if self.min_launch_minute is None:
            self.min_launch_minute = self.default_timestamp.minute
        if self.max_launch_date is None:
            self.max_launch_date = self.default_timestamp.date()
        if self.max_launch_hour is None:
            self.max_launch_hour = self.default_timestamp.hour
        if self.max_launch_minute is None:
            self.max_launch_minute = self.default_timestamp.minute

    @staticmethod
    def from_dash(raw_dash: html.Fieldset):
        min_launch_date_raw = raw_dash["props"]["children"][2]
        min_launch_date = datetime.date.fromisoformat(min_launch_date_raw)
        min_launch_hour = raw_dash["props"]["children"][3]["props"]["value"]
        min_launch_minute = raw_dash["props"]["children"][4]["props"]["value"]

        max_launch_date_raw = raw_dash["props"]["children"][8]
        max_launch_date = datetime.date.fromisoformat(max_launch_date_raw)
        max_launch_hour = raw_dash["props"]["children"][9]["props"]["value"]
        max_launch_minute = raw_dash["props"]["children"][10]["props"]["value"]

        launch_datetime_step = raw_dash["props"]["children"][14]["props"]["value"]

        return LaunchDatetimeInputs(min_launch_date=min_launch_date,
                                    min_launch_hour=min_launch_hour,
                                    min_launch_minute=min_launch_minute,
                                    max_launch_date=max_launch_date,
                                    max_launch_hour=max_launch_hour,
                                    max_launch_minute=max_launch_minute,
                                    launch_datetime_step=launch_datetime_step)

    def to_dash(self):
        return html.Fieldset(
            children=[
                html.Legend("Launch Datetime"),
                html.Label("Min", htmlFor="launch-datetime-input-min"),
                dcc.DatePickerSingle(id="launch-datetime-min-date", date=self.min_launch_date, persistence=True),
                dcc.Input(
                    id="launch-datetime-min-hour",
                    type="number",
                    min=0,
                    max=23,
                    step=1,
                    value=self.min_launch_hour,
                    persistence=True
                ),
                dcc.Input(
                    id="launch-datetime-min-minute",
                    type="number",
                    min=0,
                    max=59,
                    step=1,
                    value=self.min_launch_minute,
                    persistence=True
                ),
                html.Div(
                    id="launch-datetime-min-local",
                    children="Pacific: "
                             + datetime.datetime(self.min_launch_date.year,
                                                 self.min_launch_date.month,
                                                 self.min_launch_date.day,
                                                 self.min_launch_hour,
                                                 self.min_launch_minute)
                             .astimezone(LOCAL_TZ)
                             .strftime(LOCAL_TZ_FORMAT),
                    style={"display": "inline", "font-size": "12px"},
                ),
                html.Br(),
                html.Label("Max", htmlFor="launch-datetime-input-max"),
                dcc.DatePickerSingle(id="launch-datetime-max-date", date=self.max_launch_date, persistence=True),
                dcc.Input(
                    id="launch-datetime-max-hour",
                    type="number",
                    min=0,
                    max=23,
                    step=1,
                    value=self.max_launch_hour,
                    persistence=True
                ),
                dcc.Input(
                    id="launch-datetime-max-minute",
                    type="number",
                    min=0,
                    max=59,
                    step=1,
                    value=self.max_launch_minute,
                    persistence=True
                ),
                html.Div(
                    id="launch-datetime-max-local",
                    children="Pacific: "
                             + datetime.datetime(self.max_launch_date.year,
                                                 self.max_launch_date.month,
                                                 self.max_launch_date.day,
                                                 self.max_launch_hour,
                                                 self.max_launch_minute)
                             .astimezone(LOCAL_TZ)
                             .strftime(LOCAL_TZ_FORMAT),
                    style={"display": "inline", "font-size": "12px"},
                ),
                html.Br(),
                html.Label("Step", htmlFor="launch-datetime-step"),
                dcc.Input(id="launch-datetime-step", value=self.launch_datetime_step, persistence=True),
                dcc.Link(
                    "See Pandas docs for possible values",
                    href="https://pandas.pydata.org/pandas-docs/stable/user_guide/timeseries.html#timeseries-offset-aliases",
                    style={"font-size": "12px"},
                ),
            ]
        )


@dataclass
class FixedAscentRateInputs:
    ascent_rate_min: float = DEFAULT_ASCENT_RATE
    ascent_rate_max: float = DEFAULT_ASCENT_RATE
    ascent_rate_step: float = DEFAULT_ASCENT_RATE_STEP


@dataclass
class SmoothedAscentRateInputs:
    initial_ascent_rate: float = DEFAULT_ASCENT_RATE
    slow_down_speed_step: float = DEFAULT_ASCENT_RATE_SLOWING_RATE
    slow_down_altitude_step: float = DEFAULT_ASCENT_RATE_SLOWING_RATE_BIN


class AscentRateType(Enum):
    Fixed = "Fixed"
    Smoothed = "Smoothed"

    @staticmethod
    def from_string(s: str):
        if s == "Fixed":
            return AscentRateType.Fixed
        elif s == "Smoothed":
            return AscentRateType.Smoothed
        raise ValueError(f"Invalid ascent rate type: {s}")


@dataclass
class AscentRateInputs:
    ascent_rate_type: AscentRateType = AscentRateType.Smoothed
    fixed_ascent_rate_inputs: FixedAscentRateInputs = field(default_factory=FixedAscentRateInputs)
    smoothed_ascent_rate_inputs: SmoothedAscentRateInputs = field(default_factory=SmoothedAscentRateInputs)

    @staticmethod
    def from_dash(raw_dash: html.Fieldset):
        ascent_rate_type_raw = raw_dash["props"]["children"][2]["props"]["value"]
        ascent_rate_type = AscentRateType.from_string(ascent_rate_type_raw)

        fixed_ascent_rate_children = raw_dash["props"]["children"][4]["props"]["children"]
        fixed_ascent_rate_min = fixed_ascent_rate_children[1]["props"]["value"]
        fixed_ascent_rate_max = fixed_ascent_rate_children[4]["props"]["value"]
        fixed_ascent_rate_step = fixed_ascent_rate_children[7]["props"]["value"]
        fixed_ascent_rate_inputs = FixedAscentRateInputs(ascent_rate_min=fixed_ascent_rate_min,
                                                         ascent_rate_max=fixed_ascent_rate_max,
                                                         ascent_rate_step=fixed_ascent_rate_step)

        smoothed_ascent_rate_children = raw_dash["props"]["children"][5]["props"]["children"]
        smoothed_ascent_rate_initial = smoothed_ascent_rate_children[1]["props"]["value"]
        smoothed_ascent_rate_slow_down_speed_step = smoothed_ascent_rate_children[4]["props"]["value"]
        smoothed_ascent_rate_slow_down_altitude_step = smoothed_ascent_rate_children[7]["props"]["value"]
        smoothed_ascent_rate_inputs = SmoothedAscentRateInputs(initial_ascent_rate=smoothed_ascent_rate_initial,
                                                               slow_down_speed_step=smoothed_ascent_rate_slow_down_speed_step,
                                                               slow_down_altitude_step=smoothed_ascent_rate_slow_down_altitude_step)

        return AscentRateInputs(ascent_rate_type=ascent_rate_type,
                                fixed_ascent_rate_inputs=fixed_ascent_rate_inputs,
                                smoothed_ascent_rate_inputs=smoothed_ascent_rate_inputs)

    def to_dash(self):
        return html.Fieldset(
            children=[
                html.Legend("Ascent Rate (m/s)"),
                html.Div(
                    style={"font-size": "12px"},
                    children=[
                        "Fixed: Generate fixed ascent rates via min/max/step.",
                        html.Br(),
                        "Smoothed: When approaching initial float altitude, gradually slow down from the initial ascent rate.",
                    ],
                ),
                dcc.RadioItems(
                    id="radio-ascent-rate-type",
                    options=["Fixed", "Smoothed"],
                    value=self.ascent_rate_type.value,
                    persistence=True
                ),
                html.Br(),
                html.Div(
                    id="show-fixed-ascent-rate-inputs",
                    style={"display": "block"} if self.ascent_rate_type == AscentRateType.Fixed else {
                        "display": "none"},
                    children=[
                        html.Label("Min", htmlFor="ascent-rate-input-min"),
                        dcc.Input(
                            id="ascent-rate-input-min",
                            value=self.fixed_ascent_rate_inputs.ascent_rate_min,
                            type="number",
                            min=0.0,
                            persistence=True
                        ),
                        html.Br(),
                        html.Label("Max", htmlFor="ascent-rate-input-max"),
                        dcc.Input(
                            id="ascent-rate-input-max",
                            value=self.fixed_ascent_rate_inputs.ascent_rate_max,
                            type="number",
                            min=0.0,
                            persistence=True
                        ),
                        html.Br(),
                        html.Label("Step", htmlFor="ascent-rate-input-step"),
                        dcc.Input(
                            id="ascent-rate-input-step",
                            value=self.fixed_ascent_rate_inputs.ascent_rate_step,
                            type="number",
                            min=0.0,
                            persistence=True
                        ),
                    ],
                ),
                html.Div(
                    id="show-smoothed-ascent-rate-inputs",
                    style={"display": "block"} if self.ascent_rate_type == AscentRateType.Smoothed else {
                        "display": "none"},
                    children=[
                        html.Label(
                            "Initial ascent rate (m/s)", htmlFor="ascent-rate-input-initial"
                        ),
                        dcc.Input(
                            id="ascent-rate-smoothed-initial",
                            value=self.smoothed_ascent_rate_inputs.initial_ascent_rate,
                            type="number",
                            min=0.0,
                            persistence=True
                        ),
                        html.Br(),
                        html.Label(
                            "Slow down by X (m/s)", htmlFor="ascent-rate-slowing-rate"
                        ),
                        dcc.Input(
                            id="ascent-rate-slowing-rate",
                            value=self.smoothed_ascent_rate_inputs.slow_down_speed_step,
                            type="number",
                            min=0.0,
                            persistence=True
                        ),
                        html.Br(),
                        html.Label("Per Y meters", htmlFor="ascent-rate-slowing-rate-bin"),
                        dcc.Input(
                            id="ascent-rate-slowing-rate-bin",
                            value=self.smoothed_ascent_rate_inputs.slow_down_altitude_step,
                            type="number",
                            min=0.0,
                            persistence=True
                        ),
                    ],
                ),
            ]
        )


@dataclass
class InitialFloatAltitudeInputs:
    float_altitude_min: float = DEFAULT_FLOAT_ALTITUDE
    float_altitude_max: float = DEFAULT_FLOAT_ALTITUDE
    float_altitude_step: float = DEFAULT_FLOAT_ALTITUDE_STEP

    @staticmethod
    def from_dash(raw_dash: html.Fieldset):
        float_altitude_min = raw_dash["props"]["children"][2]["props"]["value"]
        float_altitude_max = raw_dash["props"]["children"][5]["props"]["value"]
        float_altitude_step = raw_dash["props"]["children"][8]["props"]["value"]
        return InitialFloatAltitudeInputs(float_altitude_min=float_altitude_min,
                                          float_altitude_max=float_altitude_max,
                                          float_altitude_step=float_altitude_step)

    def to_dash(self):
        return html.Fieldset(
            children=[
                html.Legend("Initial Float Altitude (m)"),
                html.Label("Min", htmlFor="float-altitude-input-min"),
                dcc.Input(
                    id="float-altitude-input-min",
                    value=self.float_altitude_min,
                    type="number",
                    persistence=True
                ),
                html.Br(),
                html.Label("Max", htmlFor="float-altitude-input-max"),
                dcc.Input(
                    id="float-altitude-input-max",
                    value=self.float_altitude_max,
                    type="number",
                    persistence=True
                ),
                html.Br(),
                html.Label("Step", htmlFor="float-altitude-input-step"),
                dcc.Input(
                    id="float-altitude-input-step",
                    value=self.float_altitude_step,
                    type="number",
                    min=0.0,
                    persistence=True
                ),
            ]
        )


@dataclass
class InitialFloatDurationInputs:
    float_duration_min: float = DEFAULT_FLOAT_DURATION_MINUTES
    float_duration_max: float = DEFAULT_FLOAT_DURATION_MINUTES
    float_duration_step: float = DEFAULT_FLOAT_DURATION_STEP

    @staticmethod
    def from_dash(raw_dash: html.Fieldset):
        float_duration_min = raw_dash["props"]["children"][2]["props"]["value"]
        float_duration_max = raw_dash["props"]["children"][6]["props"]["value"]
        float_duration_step = raw_dash["props"]["children"][10]["props"]["value"]
        return InitialFloatDurationInputs(float_duration_min=float_duration_min,
                                          float_duration_max=float_duration_max,
                                          float_duration_step=float_duration_step)

    def to_dash(self):
        return html.Fieldset(
            children=[
                html.Legend("Initial Float Duration (minutes)"),
                html.Label("Min", htmlFor="float-duration-input-min"),
                dcc.Input(
                    id="float-duration-input-min",
                    value=self.float_duration_min,
                    type="number",
                    persistence=True
                ),
                html.Label(
                    id="float-duration-input-min-pretty",
                    htmlFor="float-duration-input-min",
                    style={"font-size": "12px"},
                ),
                html.Br(),
                html.Label("Max", htmlFor="float-duration-input-max"),
                dcc.Input(
                    id="float-duration-input-max",
                    value=self.float_duration_max,
                    type="number",
                    persistence=True
                ),
                html.Label(
                    id="float-duration-input-max-pretty",
                    htmlFor="float-duration-input-max",
                    style={"font-size": "12px"},
                ),
                html.Br(),
                html.Label("Step", htmlFor="float-duration-input-step"),
                dcc.Input(
                    id="float-duration-input-step",
                    value=self.float_duration_step,
                    type="number",
                    persistence=True
                ),
                html.Label(
                    id="float-duration-input-step-pretty",
                    htmlFor="float-duration-input-step",
                    style={"font-size": "12px"},
                ),
            ]
        )


def get_default_camera_sides_selected():
    return ["Short Side"]


@dataclass
class CameraCoverageInputs:
    display: bool = False
    degrees_fov_long_side: float = 32
    degrees_fov_short_side: float = 26
    pixels_long_side: float = 640
    pixels_short_side: float = 512
    sides_selected: List[str] = field(default_factory=get_default_camera_sides_selected)
    plot_frequency_initial_ascent_descent: float = 3
    plot_frequency_float: float = 15
    plot_opacity: float = 0.5

    @staticmethod
    def from_dash(raw_dash: html.Fieldset, display: bool = False):
        degrees_fov_long_side = raw_dash["props"]["children"][4]["props"]["value"]
        degrees_fov_short_side = raw_dash["props"]["children"][7]["props"]["value"]
        pixels_long_side = raw_dash["props"]["children"][10]["props"]["value"]
        pixels_short_side = raw_dash["props"]["children"][13]["props"]["value"]
        sides_selected = raw_dash["props"]["children"][17]["props"]["value"]
        plot_frequency_initial_ascent_descent = raw_dash["props"]["children"][20]["props"]["value"]
        plot_frequency_float = raw_dash["props"]["children"][23]["props"]["value"]
        plot_opacity = raw_dash["props"]["children"][26]["props"]["value"]
        return CameraCoverageInputs(display=display,
                                    degrees_fov_long_side=degrees_fov_long_side,
                                    degrees_fov_short_side=degrees_fov_short_side,
                                    pixels_long_side=pixels_long_side,
                                    pixels_short_side=pixels_short_side,
                                    sides_selected=sides_selected,
                                    plot_frequency_initial_ascent_descent=plot_frequency_initial_ascent_descent,
                                    plot_frequency_float=plot_frequency_float,
                                    plot_opacity=plot_opacity)

    def to_dash(self):
        return html.Fieldset(
            id="camera-inputs-fieldset",
            style={"display": "block"} if self.display else {"display": "none"},
            children=[
                html.Legend("Camera Plot Settings"),
                html.Div(
                    "Settings below are defaulted to a FLIR 640",
                    style={"font-size": "12px"},
                ),
                html.Br(),
                html.Label(
                    "Degrees FOV (long side)",
                    htmlFor="camera-degrees-fov-long-side",
                ),
                dcc.Input(
                    id="camera-degrees-fov-long-side",
                    type="number",
                    min=1,
                    value=self.degrees_fov_long_side,
                    persistence=True
                ),
                html.Br(),
                html.Label(
                    "Degrees FOV (short side)",
                    htmlFor="camera-degrees-fov-short-side",
                ),
                dcc.Input(
                    id="camera-degrees-fov-short-side",
                    type="number",
                    min=1,
                    value=self.degrees_fov_short_side,
                    persistence=True
                ),
                html.Br(),
                html.Label(
                    "Pixels (long side)",
                    htmlFor="camera-pixels-long-side",
                ),
                dcc.Input(
                    id="camera-pixels-long-side",
                    type="number",
                    min=1,
                    value=self.pixels_long_side,
                    persistence=True
                ),
                html.Br(),
                html.Label(
                    "Pixels (short side)",
                    htmlFor="camera-pixels-short-side",
                ),
                dcc.Input(
                    id="camera-pixels-short-side",
                    type="number",
                    min=1,
                    value=self.pixels_short_side,
                    persistence=True
                ),
                html.Br(),
                html.Br(),
                html.Label(
                    "Image Side (a circular image is assumed in the calcs - if both sides are selected, they will be plotted separately)",
                    htmlFor="camera-side",
                ),
                dcc.Checklist(
                    id="camera-side",
                    options=["Short Side", "Long Side"],
                    value=self.sides_selected,
                    persistence=True
                ),
                html.Br(),
                html.Label(
                    "Plot Frequency - Initial Ascent/Descent (minutes)",
                    htmlFor="camera-frequency-ascent-descent-mins",
                ),
                dcc.Input(
                    id="camera-frequency-ascent-descent-mins",
                    type="number",
                    min=1,
                    value=self.plot_frequency_initial_ascent_descent,
                    step=1,
                    persistence=True
                ),
                html.Br(),
                html.Label(
                    "Plot Frequency - Float (minutes)",
                    htmlFor="camera-frequency-float-mins",
                ),
                dcc.Input(
                    id="camera-frequency-float-mins",
                    type="number",
                    min=1,
                    value=self.plot_frequency_float,
                    step=1,
                    persistence=True
                ),
                html.Br(),
                html.Label("Plot Opacity (0.0-1.0)", htmlFor="camera-opacity"),
                dcc.Input(id="camera-opacity", type="number", min=0.0, max=1.0, value=self.plot_opacity,
                          persistence=True),
            ],
        )


@dataclass
class WindMapSettingsInputs:
    show_wind_map: bool = False
    wind_map_style: str = "open-street-map"

    @staticmethod
    def from_dash(raw_dash: html.Fieldset):
        show_wind_map_raw = raw_dash["props"]["children"][1]["props"]["value"]
        show_wind_map = bool(show_wind_map_raw)
        wind_map_style = raw_dash["props"]["children"][4]["props"]["value"]
        return WindMapSettingsInputs(show_wind_map=show_wind_map, wind_map_style=wind_map_style)

    def to_dash(self):
        wind_map_style_options = ["open-street-map", "stamen-terrain", "cartopy-plain"]
        return html.Fieldset(
            id="wind-map-settings-fieldset",
            children=[
                html.Legend("Wind Map Settings"),
                dcc.Checklist(
                    id="wind-map-enable",
                    options=[
                        {
                            "label": "Show GFS wind map",
                            "value": "Show",
                        },
                    ],
                    value=["Show"] if self.show_wind_map else [],
                    persistence=True
                ),
                html.Br(),
                html.Label("Wind Map Style", htmlFor="wind-map-style"),
                dcc.Dropdown(
                    id="wind-map-style-dropdown", options=wind_map_style_options, value=self.wind_map_style,
                    persistence=True
                )])


@dataclass
class MapSettingsInputs:
    show_camera_image_coverage: bool = False
    show_key_event_markers: bool = True
    mapbox_style: str = "open-street-map"
    color_palette: str = "Dark24"
    reverse_color_palette: bool = False

    @staticmethod
    def from_dash(raw_dash: html.Fieldset):
        show_camera_image_coverage_raw = raw_dash["props"]["children"][1]["props"]["value"]
        show_camera_image_coverage = bool(show_camera_image_coverage_raw)
        show_key_event_markers_raw = raw_dash["props"]["children"][2]["props"]["value"]
        show_key_event_markers = bool(show_key_event_markers_raw)
        mapbox_style = raw_dash["props"]["children"][7]["props"]["value"]
        color_palette = raw_dash["props"]["children"][10]["props"]["value"]
        reverse_color_palette_raw = raw_dash["props"]["children"][11]["props"]["value"]
        reverse_color_palette = bool(reverse_color_palette_raw)
        return MapSettingsInputs(show_camera_image_coverage=show_camera_image_coverage,
                                 show_key_event_markers=show_key_event_markers,
                                 mapbox_style=mapbox_style,
                                 color_palette=color_palette,
                                 reverse_color_palette=reverse_color_palette)

    def to_dash(self):
        qualitative_color_options = [
            {"label": f"{v} (qualitative)", "value": v} for v in QUALITATIVE_COLOR_NAMES
        ]
        sequential_color_options = [
            {"label": f"{v} (sequential)", "value": v} for v in SEQUENTIAL_COLOR_NAMES
        ]
        all_color_options = qualitative_color_options + sequential_color_options

        mapbox_styles_no_key_reqd = [
            {"label": v, "value": v}
            for v in [
                "open-street-map",
                "white-bg",
                "carto-positron",
                "carto-darkmatter",
                "stamen-terrain",
                "stamen-toner",
                "stamen-watercolor",
            ]
        ]
        mapbox_styles_key_reqd = [
            {"label": f"{v} (Mapbox API token required)", "value": v}
            for v in [
                "basic",
                "streets",
                "outdoors",
                "light",
                "dark",
                "satellite",
                "satellite-streets",
            ]
        ]

        mapbox_styles = mapbox_styles_no_key_reqd + mapbox_styles_key_reqd

        return html.Fieldset(
            id="map-settings-fieldset",
            children=[
                html.Legend("Map Settings"),
                dcc.Checklist(
                    id="camera-enable",
                    options=[
                        {
                            "label": "Show camera image coverage",
                            "value": "Show",
                        },
                    ],
                    value=["Show"] if self.show_camera_image_coverage else [],
                    persistence=True
                ),
                dcc.Checklist(
                    id="map-settings-showmarkers",
                    options=[{"label": "Show key event markers", "value": "Show"}],
                    value=["Show"] if self.show_key_event_markers else [],
                    persistence=True
                ),
                html.Br(),
                html.Label("Mapbox Style", htmlFor="mapbox-style"),
                html.Br(),
                html.Label(
                    "A Mapbox API token is required for some styles. Set via environment variable MAPBOX_TOKEN",
                    htmlFor="mapbox-style",
                    style={"font-size": "12px"},
                ),
                dcc.Dropdown(
                    id="mapbox-style", options=mapbox_styles, value=self.mapbox_style, persistence=True
                ),
                html.Br(),
                html.Label("Color Palette", htmlFor="color-palette-dropdown"),
                dcc.Dropdown(
                    id="color-palette-dropdown", options=all_color_options, value=self.color_palette, persistence=True
                ),
                dcc.Checklist(
                    id="color-palette-reverse",
                    options=[{"label": "Reverse color palette", "value": "Reverse"}],
                    value=["Reverse"] if self.reverse_color_palette else [],
                    persistence=True
                ),
                html.Button(
                    "Show/Hide Color Swatches",
                    id="show-hide-color-swatches-btn",
                    className="btn",
                ),
                html.Div(
                    id="color-swatches",
                    style={"display": "none"},
                    children=[
                        dcc.Graph(
                            id="color-swatches-qualitative",
                            figure=QUALITATIVE_SWATCHES_FIG,
                        ),
                        dcc.Graph(
                            id="color-swatches-sequential",
                            figure=SEQUENTIAL_SWATCHES_FIG,
                        ),
                    ],
                ),
            ],
        )


def get_default_descent_rates():
    return [DEFAULT_DESCENT_RATE]


@dataclass
class DescentRateInputs:
    descent_rates: List[float] = field(default_factory=get_default_descent_rates)

    @staticmethod
    def from_dash(raw_dash: html.Fieldset):
        descent_rates_str = raw_dash["props"]["children"][2]["props"]["value"]
        descent_rates = [float(x) for x in descent_rates_str.split(",")]
        return DescentRateInputs(descent_rates=descent_rates)

    def to_dash(self):
        descent_rates_str = ",".join(str(s) for s in self.descent_rates)
        return html.Fieldset(
            children=[
                html.Legend("Descent Rate (m/s)"),
                html.Label("Descent Rates (comma separated)", htmlFor="descent-rate-input"),
                dcc.Input(id="descent-rate-input", value=descent_rates_str, type="text", persistence=True),
            ]
        )


@dataclass
class EnsembleFormInputs:
    lat_lon_inputs: LatLonInputs = field(default_factory=LatLonInputs)
    launch_altitude_inputs: LaunchAltitudeInputs = field(default_factory=LaunchAltitudeInputs)
    launch_datetime_inputs: LaunchDatetimeInputs = field(default_factory=LaunchDatetimeInputs)
    ascent_rate_inputs: AscentRateInputs = field(default_factory=AscentRateInputs)
    initial_float_altitude_inputs: InitialFloatAltitudeInputs = field(default_factory=InitialFloatAltitudeInputs)
    initial_float_duration_inputs: InitialFloatDurationInputs = field(default_factory=InitialFloatDurationInputs)
    descent_rate_inputs: DescentRateInputs = field(default_factory=DescentRateInputs)
    map_settings_inputs: MapSettingsInputs = field(default_factory=MapSettingsInputs)
    camera_coverage_inputs: CameraCoverageInputs = field(default_factory=CameraCoverageInputs)
    wind_map_settings_inputs: WindMapSettingsInputs = field(default_factory=WindMapSettingsInputs)

    @staticmethod
    def from_dash(raw_dash: html.Div):
        lat_lon_inputs_raw = raw_dash["props"]["children"][0]
        lat_lon_inputs = LatLonInputs.from_dash(lat_lon_inputs_raw)
        launch_altitude_inputs_raw = raw_dash["props"]["children"][1]
        launch_altitude_inputs = LaunchAltitudeInputs.from_dash(launch_altitude_inputs_raw)
        launch_datetime_inputs_raw = raw_dash["props"]["children"][2]
        launch_datetime_inputs = LaunchDatetimeInputs.from_dash(launch_datetime_inputs_raw)
        ascent_rate_inputs_raw = raw_dash["props"]["children"][3]
        ascent_rate_inputs = AscentRateInputs.from_dash(ascent_rate_inputs_raw)
        initial_float_altitude_inputs_raw = raw_dash["props"]["children"][4]
        initial_float_altitude_inputs = InitialFloatAltitudeInputs.from_dash(initial_float_altitude_inputs_raw)
        initial_float_duration_inputs_raw = raw_dash["props"]["children"][5]
        initial_float_duration_inputs = InitialFloatDurationInputs.from_dash(initial_float_duration_inputs_raw)
        descent_rate_inputs_raw = raw_dash["props"]["children"][6]
        descent_rate_inputs = DescentRateInputs.from_dash(descent_rate_inputs_raw)
        map_settings_inputs_raw = raw_dash["props"]["children"][7]
        map_settings_inputs = MapSettingsInputs.from_dash(map_settings_inputs_raw)
        camera_coverage_inputs_raw = raw_dash["props"]["children"][8]
        camera_coverage_inputs = CameraCoverageInputs.from_dash(camera_coverage_inputs_raw,
                                                                map_settings_inputs.show_camera_image_coverage)
        wind_map_settings_inputs_raw = raw_dash["props"]["children"][9]
        wind_map_settings_inputs = WindMapSettingsInputs.from_dash(wind_map_settings_inputs_raw)

        return EnsembleFormInputs(lat_lon_inputs=lat_lon_inputs,
                                  launch_altitude_inputs=launch_altitude_inputs,
                                  launch_datetime_inputs=launch_datetime_inputs,
                                  ascent_rate_inputs=ascent_rate_inputs,
                                  initial_float_altitude_inputs=initial_float_altitude_inputs,
                                  initial_float_duration_inputs=initial_float_duration_inputs,
                                  descent_rate_inputs=descent_rate_inputs,
                                  map_settings_inputs=map_settings_inputs,
                                  camera_coverage_inputs=camera_coverage_inputs,
                                  wind_map_settings_inputs=wind_map_settings_inputs)

    def to_dash(self):
        return html.Div(
            className="parameter-input-form",
            children=[
                self.lat_lon_inputs.to_dash(),
                self.launch_altitude_inputs.to_dash(),
                self.launch_datetime_inputs.to_dash(),
                self.ascent_rate_inputs.to_dash(),
                self.initial_float_altitude_inputs.to_dash(),
                self.initial_float_duration_inputs.to_dash(),
                self.descent_rate_inputs.to_dash(),
                self.map_settings_inputs.to_dash(),
                self.camera_coverage_inputs.to_dash(),
                self.wind_map_settings_inputs.to_dash()
            ],
        )


def render_error_list(title: str, errors: Optional[List[str]]):
    if errors:
        error_items = [html.Li(err) for err in errors]
        return [html.H3(title), html.Ul(children=error_items)]
    else:
        return []


def render_error_message_container_style(errors):
    if errors:
        return {"display": "block", "background-color": "#f44336", "color": "white"}
    else:
        return {"display": "none"}


def render_simulation_errors(errors: List[str]):
    if errors:
        error_items = [html.Li(err) for err in errors]
        return [html.H3("Simulation/API errors"), html.Ul(children=error_items)]
    else:
        return []


def render_latlon_map_style(display: bool):
    if display:
        return {"display": "block", "padding": "0px, 0px, 0px, 0px"}
    else:
        return {"display": "none"}
