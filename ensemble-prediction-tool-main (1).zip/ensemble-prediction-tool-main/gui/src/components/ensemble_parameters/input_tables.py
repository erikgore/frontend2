import csv
import datetime
import os
from dataclasses import dataclass
from typing import List, Optional

from dash import dash_table, dcc, html
from dash.dash_table.Format import Format, Symbol
from dateutil.parser import isoparse


@dataclass
class SmoothedAscentRate:
    initial_rate: float
    slowing_rate_m_s: float
    slowing_rate_bin_m: float


def get_default_float_configs():
    float_configs = {}
    dir_path = os.path.join(os.path.dirname(__file__), "preset_tables", "float_configs")
    for dir_entry in os.scandir(dir_path):
        with open(dir_entry.path) as fp:
            float_config = []
            reader = csv.DictReader(fp)
            for row in reader:
                row_converted = {k: float(v) for k, v in row.items()}
                float_config.append(row_converted)
            clean_file_name = dir_entry.name.replace(".csv", "")
            float_configs[clean_file_name] = float_config
    return float_configs


DEFAULT_FLOAT_CONFIGS = get_default_float_configs()


class FloatConfig:
    def __init__(self,
                 float_config_id: str,
                 available_launch_config_ids: List[str],
                 selected_launch_config_ids: List[str] = None,
                 num_rows: int = 1,
                 data: List[dict] = None):
        self.float_config_id = float_config_id
        self.available_launch_config_ids = available_launch_config_ids
        self.selected_launch_config_ids = selected_launch_config_ids or []
        self.data = data
        if self.data is None:
            self.data = [
                {
                    "altitude": "",
                    "ascent_descent_rate": "",
                    "float_duration": "",
                }
                for _ in range(num_rows)
            ]

    @staticmethod
    def from_dash(raw_dash: html.Div):
        float_config_id = raw_dash["props"]["id"]["index"]
        available_launch_config_ids = raw_dash["props"]["children"][2]["props"]["options"]
        selected_launch_config_ids = raw_dash["props"]["children"][2]["props"].get("value", [])
        data = raw_dash["props"]["children"][7]["props"]["data"]
        return FloatConfig(float_config_id=float_config_id,
                           available_launch_config_ids=available_launch_config_ids,
                           selected_launch_config_ids=selected_launch_config_ids,
                           data=data)

    def to_dash(self):
        return html.Div(
            id={"type": "float-config-div", "index": self.float_config_id},
            children=[
                html.H3(f"Float config - {self.float_config_id}"),
                html.Label("Applies to flight profiles:"),
                dcc.Dropdown(
                    id={"type": "float-config-id-dropdown", "index": self.float_config_id},
                    options=self.available_launch_config_ids,
                    multi=True,
                    value=self.selected_launch_config_ids,
                ),
                html.Br(),
                html.Label("Apply preset config:"),
                dcc.Dropdown(
                    id={"type": "float-config-default-dropdown", "index": self.float_config_id},
                    options=[k for k in DEFAULT_FLOAT_CONFIGS.keys()],
                ),
                html.Br(),
                dash_table.DataTable(
                    id={
                        "type": "flight-ensemble-table-multifloat-config",
                        "index": self.float_config_id,
                    },
                    columns=(
                        [
                            {
                                "id": "altitude",
                                "name": "New Float Altitude (m)",
                                "type": "numeric",
                                "format": Format(
                                    group=True, symbol=Symbol.yes, symbol_suffix=" m"
                                ),
                            },
                            {
                                "id": "ascent_descent_rate",
                                "name": "Ascent/Descent Rate (m/s)",
                                "type": "numeric",
                                "format": Format(
                                    group=True, symbol=Symbol.yes, symbol_suffix=" m/s"
                                ),
                            },
                            {
                                "id": "float_duration",
                                "name": "Float Duration (minutes)",
                                "type": "numeric",
                                "format": Format(
                                    group=True, symbol=Symbol.yes, symbol_suffix=" m"
                                ),
                            },
                        ]
                    ),
                    data=self.data,
                    editable=True,
                ),
                html.Button(
                    "Add row",
                    className="btn",
                    id={"type": "float-config-add-row-btn", "index": self.float_config_id},
                ),
            ],
        )


class LaunchConfig:
    def __init__(self, data: List[dict]):
        self.data = data

    def get_flight_profile_ids(self):
        return list(set(d["flight_profile_id"] for d in self.data))

    @staticmethod
    def from_ensemble_inputs(
            launch_latitudes: List[float],
            launch_longitudes: List[float],
            launch_datetimes: List[datetime.datetime],
            descent_rates: List[float],
            altitudes: Optional[List[float]] = None,
    ):
        data = []
        flight_profile_id = 1
        if altitudes:
            for launch_latitude in launch_latitudes:
                for launch_longitude in launch_longitudes:
                    for altitude in altitudes:
                        for launch_datetime in launch_datetimes:
                            for descent_rate in descent_rates:
                                data.append(
                                    {
                                        "flight_profile_id": str(flight_profile_id),
                                        "latitude": launch_latitude,
                                        "longitude": launch_longitude,
                                        "altitude": altitude,
                                        "launch_datetime": launch_datetime,
                                        "descent_rate": descent_rate,
                                    }
                                )
                                flight_profile_id += 1
        else:
            for launch_latitude in launch_latitudes:
                for launch_longitude in launch_longitudes:
                    for launch_datetime in launch_datetimes:
                        for descent_rate in descent_rates:
                            data.append(
                                {
                                    "flight_profile_id": str(flight_profile_id),
                                    "latitude": launch_latitude,
                                    "longitude": launch_longitude,
                                    "altitude": "",
                                    "launch_datetime": launch_datetime,
                                    "descent_rate": descent_rate,
                                }
                            )
                            flight_profile_id += 1
        return LaunchConfig(data=data)

    @staticmethod
    def from_dash(raw_dash: dash_table.DataTable):
        data = raw_dash["props"]["data"]
        return LaunchConfig(data=data)

    def to_dash(self):
        return dash_table.DataTable(
            id="flight-ensemble-table-multifloat",
            columns=(
                [
                    {
                        "id": "flight_profile_id",
                        "name": "Flight Profile ID",
                    },
                    {"id": "latitude", "name": "Latitude", "type": "numeric"},
                    {"id": "longitude", "name": "Longitude", "type": "numeric"},
                    {
                        "id": "altitude",
                        "name": "Launch Altitude (m)",
                        "type": "numeric",
                        "format": Format(group=True, symbol=Symbol.yes, symbol_suffix=" m"),
                    },
                    {"id": "launch_datetime", "name": "Launch Datetime"},
                    {
                        "id": "descent_rate",
                        "name": "Final Descent Rate (m/s)",
                        "type": "numeric",
                        "format": Format(
                            group=True, symbol=Symbol.yes, symbol_suffix=" m/s"
                        ),
                    },
                ]
            ),
            tooltip_header={"launch_datetime": "Format: %Y-%m-%dT%H:%M:%S.%fZ"},
            data=self.data,
            editable=True,
        )


@dataclass
class EstimatedLandingDatetime:
    flight_profile_id: str
    float_config_id: str
    landing_datetime: datetime.datetime


class EnsembleContainer:
    def __init__(self, launch_config: LaunchConfig, float_configs: List[FloatConfig]):
        self.launch_config = launch_config
        self.float_configs = float_configs

    def get_estimated_landing_datetimes(self) -> List[EstimatedLandingDatetime]:
        estimated_landing_datetimes = []
        for launch_config_row in self.launch_config.data:
            flight_profile_id = launch_config_row["flight_profile_id"]
            for float_config in self.float_configs:
                if flight_profile_id not in float_config.selected_launch_config_ids:
                    pass
                # Only consider float time, not ascent/descent, for simplicity
                float_duration_mins = 0
                for float_config_row in float_config.data:
                    if all(str(v) != "" for v in float_config_row.values()):
                        float_duration_mins += float_config_row["float_duration"]

                estimated_landing_time = isoparse(launch_config_row["launch_datetime"]) + datetime.timedelta(
                    minutes=float_duration_mins)
                estimated_landing_dt = EstimatedLandingDatetime(flight_profile_id=flight_profile_id,
                                                                float_config_id=float_config.float_config_id,
                                                                landing_datetime=estimated_landing_time)
                estimated_landing_datetimes.append(estimated_landing_dt)
        return estimated_landing_datetimes

    def to_dash(self):
        children = (
                [
                    html.H2("Launch/descent configs"),
                    self.launch_config.to_dash(),
                    html.Button("Add row", id="add-row-table-multifloat-btn", className="btn"),
                    html.H2("Float configs"),
                ]
                + [fc.to_dash() for fc in self.float_configs]
                + [
                    html.Button(
                        "Add float config table",
                        id="add-float-config-table-btn",
                        className="btn",
                    )
                ]
        )

        return html.Div(id="flight-ensemble-table-multifloat-container", children=children)

    @staticmethod
    def from_ensemble_inputs(
            launch_latitudes: List[float],
            launch_longitudes: List[float],
            launch_datetimes: List[datetime.datetime],
            float_altitudes: List[float],
            float_durations: List[float],
            final_descent_rates: List[float],
            launch_altitudes: Optional[List[float]] = None,
            fixed_ascent_rates: Optional[List[float]] = None,
            smoothed_ascent_rate: Optional[SmoothedAscentRate] = None,
    ):
        launch_config = LaunchConfig.from_ensemble_inputs(launch_latitudes=launch_latitudes,
                                                          launch_longitudes=launch_longitudes,
                                                          launch_datetimes=launch_datetimes,
                                                          descent_rates=final_descent_rates,
                                                          altitudes=launch_altitudes)
        flight_profile_ids = launch_config.get_flight_profile_ids()

        float_configs = []
        float_config_counter = 1
        for float_altitude in float_altitudes:
            for float_duration in float_durations:
                if smoothed_ascent_rate is not None:
                    current_ascent_rate = smoothed_ascent_rate.initial_rate

                    slowing_start_alt = float_altitude - (
                            smoothed_ascent_rate.initial_rate / smoothed_ascent_rate.slowing_rate_m_s - 1) * smoothed_ascent_rate.slowing_rate_bin_m
                    current_alt = slowing_start_alt

                    data = []
                    if current_alt > float_altitude:
                        # No slowing needed - just ascend at the initial rate to float altitude
                        data.append(
                            {
                                "altitude": float_altitude,
                                "ascent_descent_rate": current_ascent_rate,
                                "float_duration": float_duration,
                            }
                        )

                    while current_alt < float_altitude and current_ascent_rate > 0:
                        data.append(
                            {
                                "altitude": current_alt,
                                "ascent_descent_rate": current_ascent_rate,
                                "float_duration": 0,  # No float, just changing the ascent rate
                            }
                        )

                        current_alt = min(
                            float_altitude,
                            current_alt + smoothed_ascent_rate.slowing_rate_bin_m,
                        )
                        if current_ascent_rate - smoothed_ascent_rate.slowing_rate_m_s > 0:
                            current_ascent_rate -= smoothed_ascent_rate.slowing_rate_m_s

                        if current_alt == float_altitude:
                            # We've reached float altitude, now float for the full duration
                            data.append(
                                {
                                    "altitude": float_altitude,
                                    "ascent_descent_rate": current_ascent_rate,
                                    "float_duration": float_duration,
                                }
                            )

                    float_config = FloatConfig(
                        float_config_id=str(float_config_counter),
                        available_launch_config_ids=flight_profile_ids,
                        selected_launch_config_ids=flight_profile_ids,
                        data=data,
                    )
                    float_configs.append(float_config)
                    float_config_counter += 1

                else:
                    for ascent_rate in fixed_ascent_rates:
                        data = [
                            {
                                "altitude": float_altitude,
                                "ascent_descent_rate": ascent_rate,
                                "float_duration": float_duration,
                            }
                        ]
                        float_config = FloatConfig(
                            float_config_id=str(float_config_counter),
                            available_launch_config_ids=flight_profile_ids,
                            selected_launch_config_ids=flight_profile_ids,
                            data=data,
                        )
                        float_configs.append(float_config)
                        float_config_counter += 1

        return EnsembleContainer(launch_config=launch_config, float_configs=float_configs)

    @staticmethod
    def from_dash(raw_dash):
        launch_config_table_raw = raw_dash[1]
        launch_config = LaunchConfig.from_dash(launch_config_table_raw)

        float_config_tables_raw = raw_dash[4:-1]
        float_configs = [FloatConfig.from_dash(r) for r in float_config_tables_raw]

        return EnsembleContainer(launch_config=launch_config, float_configs=float_configs)

    def add_launch_config_row(self):
        max_profile_id_int = 0
        for d in self.launch_config.data:
            try:
                i = int(d["flight_profile_id"])
                if i > max_profile_id_int:
                    max_profile_id_int = i
            except ValueError:
                pass

        self.launch_config.data.append(
            {
                "flight_profile_id": str(max_profile_id_int + 1),
                "latitude": "",
                "longitude": "",
                "altitude": "",
                "launch_datetime": "",
                "descent_rate": "",
            }
        )

        for fc in self.float_configs:
            fc.available_launch_config_ids.append(str(max_profile_id_int + 1))

    def refresh_launch_config_options(self):
        flight_profile_ids = self.launch_config.get_flight_profile_ids()

        for fc in self.float_configs:
            fc.available_launch_config_ids = flight_profile_ids

    def add_float_config(self):
        flight_profile_ids = self.launch_config.get_flight_profile_ids()

        max_float_config_id_int = 0
        for fc in self.float_configs:
            try:
                i = int(fc.float_config_id)
                if i > max_float_config_id_int:
                    max_float_config_id_int = i
            except ValueError:
                pass
        self.float_configs.append(
            FloatConfig(float_config_id=str(max_float_config_id_int + 1),
                        available_launch_config_ids=flight_profile_ids))
