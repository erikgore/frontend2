import os

import diskcache
import flask
from dash import Dash, page_container
from dash.long_callback import DiskcacheLongCallbackManager

from components.ensemble_parameters.constants import DOWNLOADS_FOLDER

cache = diskcache.Cache("./cache")
long_callback_manager = DiskcacheLongCallbackManager(cache)

app = Dash(
    "ensemble-flight-prediction",
    title="Ensemble Flight Prediction",
    long_callback_manager=long_callback_manager,
    use_pages=True,
    compress=True,  # Compress files and data served by Flask
    serve_locally=False,  # Dash JS/CSS files served by CDN links - will be cached by browser
)

app.layout = page_container


# Endpoint to download a single file from the DOWNLOADS_FOLDER directory
# Implemented as a plain Flask endpoint, using the underlying Flask server within the Dash app
@app.server.route("/file_downloads/<file_name>")
def download_file(file_name: str):
    file_path = os.path.join(DOWNLOADS_FOLDER, file_name)
    return flask.send_file(file_path, mimetype="application/zip", as_attachment=True)


# Endpoint to delete a single file from the DOWNLOADS_FOLDER directory
# Implemented as a plain Flask endpoint, using the underlying Flask server within the Dash app
@app.server.route("/delete_file/<file_name>")
def delete_file(file_name: str):
    file_path = os.path.join(DOWNLOADS_FOLDER, file_name)
    os.unlink(file_path)
    return flask.redirect("/file_downloads")
