## Ensemble Prediction Tool

Purpose: Forecast flight paths using an ensemble of inputs (lat/longs, altitudes, ascent rates, etc)

The prediction model used is Tawhiri v2, i.e. the API used by Sondehub Predict.

### Architecture

This is a [Dash](https://dash.plotly.com) app (Dash is a package to create interactive dashboards in pure Python).
It uses [Plotly](https://plotly.com/python/) for charting.

#### Directories

`assets`: Static assets in this folder are automatically included by Dash (for CSS, icons, etc).

`components`: Some of the more complex Dash components, like the ensemble input table.

`app.py`: The main file to initialize and run the app.

`tawhiri.py`: Tawhiri-specific code. Different classes for each prediction type, along with generic functions to make
requests to the Tawhiri API.

### Third-Party Services

The Mapbox API is used by Plotly for the map output.
No API key is needed (currently) for the open-street-map style.
To use other map styles, you can set the API key via the environment variable: `MAPBOX_TOKEN`

Sondehub's [Tawhiri v2 API](https://github.com/projecthorus/tawhiri) is used to get the flight trajectories.
No API key is needed and it's a public API, although the API is mainly intended for Sondehub Predict and they may apply
rate limiting, etc.
Override the URL via the environment variable: `TAWHIRI_API_URL`

NASA GNSS files are used for generating GPS sim data.
These files are downloaded by a separate container (ephemeris_downloader).
Set the base directory to match with ephemeris_downloader, using environment variable `GNSS_DIR`.
`GNSS_DIR` defaults to `/gnss_data`

Microloon (Iridium) data is pulled via an Influx database. The Influx connection is configured via environment variables:

`INFLUX_HOST` : Influx DB hostname

`INFLUX_PORT` : Influx DB port (defaults to 8086)

`INFLUX_DATABASE` : Influx DB name

`INFLUX_USER` : Influx DB user

`INFLUX_PASSWORD` : Influx DB password

### Building/Running

You can use the Dockerfile, exposing port `8050` (and optionally providing a `MAPBOX_TOKEN` and/or `TAWHIRI_API_URL`
environment variables).

Or, just `python3 -m pip install -r requirements.txt` then `python3 src/app.py`
