## Ruaumoko elevation downloader

Downloads elevation data and saves it to disk.

[PyPi link](https://pypi.org/project/Ruaumoko/)
