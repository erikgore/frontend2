## Downloadable File Cleaner

Deletes downloadable files older than a certain number of hours to free up disk space.
Intended to be mounted in a Kubernetes Pod to clean up files from a volume.

### Environment Variables

`DAYS_CUTOFF` : Files older than `HOURS_CUTOFF` hours will be deleted.

`CLEAN_DIRECTORY` : Directory from which to delete files.