#!/usr/bin/env bash

# Check that the environment variables are set
[ -z "$DAYS_CUTOFF" ] && echo "Need to set DAYS_CUTOFF environment variable" && exit 1;
[ -z "$CLEAN_DIRECTORY" ] && echo "Need to set CLEAN_DIRECTORY environment variable" && exit 1;

while true
do
    echo "Cleaning files older than $DAYS_CUTOFF from directory $CLEAN_DIRECTORY";
    find "$CLEAN_DIRECTORY" -mtime +"$DAYS_CUTOFF" -exec rm {} \;
    sleep 60m;
done