# Flight Prediction Stack

## Components

There are 4 components to the flight prediction stack. Each of these is containerized for convenience.

| Service             | Purpose                          | Depends on                          | GitHub                                                                                                    | Container Image                                                                                                                  |
|---------------------|----------------------------------|-------------------------------------|-----------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------|
| GFS downloader      | Save GFS files to disk           |                                     | [projecthorus/tawhiri-downloader-container](https://github.com/projecthorus/tawhiri-downloader-container) | [On GitHub - prebuilt](https://github.com/projecthorus/tawhiri-downloader-container/pkgs/container/tawhiri-downloader-container) |
| Ruaumoko downloader | Save elevation data to disk      |                                     | [cuspaceflight/ruaumoko](https://github.com/cuspaceflight/ruaumoko)                                       | [In this repo - must be built](./ruaumoko/Dockerfile)                                                                            |
| Tawhiri API         | Flask API for flight prediction  | GFS downloader, Ruaumoko downloader | [projecthorus/tawhiri](https://github.com/projecthorus/tawhiri)                                           | [On GitHub - prebuilt](https://github.com/projecthorus/tawhiri/pkgs/container/tawhiri)                                           |
| Dash app            | GUI for running flight scenarios | Tawhiri API                         | [balloontech/ensemble-prediction-tool](https://github.com/balloontech/ensemble-prediction-tool)           | [In this repo - must be built](./gui/Dockerfile)                                                                                 |

The containers for the GFS downloader and Tawhiri API are already built on GitHub.
The containers for the Ruaumoko downloader and Dash app must be built. Their Dockerfiles are in this repo. They can be built automatically using `docker compose up` as below, or individually via `docker build` on the appropriate Dockerfile.

To run all 4 services, you can just `cd` to this directory and do `docker compose up`, which will:
1. Download and/or build the container images
2. Run the Ruaumoko downloader to completion to get the elevation files
3. Start the GFS downloader, Tawhiri API, and Dash app and run them

Then you can access the GUI at http://localhost:8050 or the Tawhiri API at http://localhost:8000 .
If either downloader fails, check that there is enough storage space in Docker (at least ~15gb free space).
